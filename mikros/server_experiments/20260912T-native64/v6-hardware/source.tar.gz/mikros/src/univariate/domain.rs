//! Fixed interpolation domains for the intermediate-field Hadamard reduction.
//!
//! H is the first 128 AES-field elements; the certificate uses the first 255
//! elements. Tables depend only on these public domains and are shared between
//! proofs. Flock's 128-point continuation table supplies the native row path.

use std::sync::OnceLock;

use flock_core::ntt::{AdditiveNttGf8, inv_table::InvNttTableByteSingleGf8};
use flock_field::{F8, F128};

use super::field::field;

const KAPPA: usize = 128;
const QUOTIENTS: usize = 127;
const SAMPLES: usize = 255;
const COORDINATES: usize = 16;

pub(crate) struct Domain {
    nodes: [F128; KAPPA],
    denominator_inverses: [F128; KAPPA],
    h_on_lambda: Vec<[u8; KAPPA]>,
    psi_inverse_on_lambda: [u8; QUOTIENTS],
    lambda_basis: Vec<[u8; QUOTIENTS]>,
    row_tables: Vec<[u8; QUOTIENTS]>,
    native_table: InvNttTableByteSingleGf8,
}

pub(crate) fn domain() -> &'static Domain {
    static DOMAIN: OnceLock<Domain> = OnceLock::new();
    DOMAIN.get_or_init(Domain::new)
}

impl Domain {
    /// The same Flock continuation, retained in registers for fused consumers.
    ///
    /// # Safety
    /// Requires AVX-512F. This domain owns the fixed k=7 table, and the array
    /// reference provides exactly the sixteen input bytes required by Flock.
    #[cfg(target_arch = "x86_64")]
    #[inline]
    #[target_feature(enable = "avx512f")]
    pub(crate) unsafe fn continuation_registers(
        &self,
        row: &[u8; 16],
    ) -> [std::arch::x86_64::__m512i; 2] {
        // SAFETY: constructor fixes ell=128/n_chunks=16; features declared.
        unsafe {
            self.native_table
                .apply_x86_avx512_128_register_unchecked(row.as_ptr())
        }
    }

    fn new() -> Self {
        let f = field();
        let h: Vec<_> = (0..KAPPA).map(|x| x as u8).collect();
        let lambda: Vec<_> = (KAPPA..SAMPLES).map(|x| x as u8).collect();
        let psi = vanishing_polynomial(&h);
        let (h_basis, h_denominator_inverses) = lagrange_basis(&h);
        let (lambda_basis, _) = lagrange_basis(&lambda);
        let h_on_lambda: Vec<[u8; KAPPA]> = lambda
            .iter()
            .map(|&x| std::array::from_fn(|i| evaluate(&h_basis[i], x)))
            .collect();
        let psi_inverse_on_lambda = std::array::from_fn(|i| {
            let value = evaluate(&psi, lambda[i]);
            assert_ne!(value, 0, "the interpolation domains must be disjoint");
            f.inv(value)
        });
        let lambda_basis = lambda_basis
            .into_iter()
            .map(|p| p.try_into().expect("127-point interpolation basis"))
            .collect();

        // Each table maps one witness byte to its 127 off-domain samples.
        // Building a subset from its lowest bit takes only 127 byte XORs.
        let mut row_tables = vec![[0; QUOTIENTS]; COORDINATES * 256];
        for chunk in 0..COORDINATES {
            for byte in 1usize..256 {
                let bit = byte.trailing_zeros() as usize;
                let previous = chunk * 256 + (byte & (byte - 1));
                let current = chunk * 256 + byte;
                for (sample, weights) in h_on_lambda.iter().enumerate() {
                    row_tables[current][sample] =
                        row_tables[previous][sample] ^ weights[chunk * 8 + bit];
                }
            }
        }
        let ntt_h = AdditiveNttGf8::new(7, F8::ZERO);
        let ntt_lambda = AdditiveNttGf8::new(7, F8(128));
        Self {
            nodes: std::array::from_fn(|i| f.embed(i as u8)),
            denominator_inverses: std::array::from_fn(|i| f.embed(h_denominator_inverses[i])),
            h_on_lambda,
            psi_inverse_on_lambda,
            lambda_basis,
            row_tables,
            native_table: InvNttTableByteSingleGf8::new(&ntt_h, &ntt_lambda),
        }
    }

    /// The 128 Lagrange weights on H, including challenges that belong to H.
    /// Prefix/suffix products avoid inversions and their exceptional zero case.
    pub(crate) fn lagrange_at(&self, x: F128) -> Vec<F128> {
        let mut prefix = [F128::ONE; KAPPA + 1];
        for (i, &node) in self.nodes.iter().enumerate() {
            prefix[i + 1] = prefix[i] * (x + node);
        }
        let mut suffix = F128::ONE;
        let mut weights = vec![F128::ZERO; KAPPA];
        for i in (0..KAPPA).rev() {
            weights[i] = prefix[i] * suffix * self.denominator_inverses[i];
            suffix *= x + self.nodes[i];
        }
        weights
    }

    pub(crate) fn vanishing_at(&self, x: F128) -> F128 {
        self.nodes
            .iter()
            .fold(F128::ONE, |product, &node| product * (x + node))
    }

    pub(crate) fn contains(&self, x: F128) -> bool {
        self.nodes.contains(&x)
    }

    /// Turn the 255 coordinate-wise aggregate samples into h's 127 monomial
    /// coefficients, in ascending degree order. In characteristic two,
    /// subtraction of the interpolated column polynomial is byte XOR.
    pub(crate) fn quotient(&self, samples: &[[u8; COORDINATES]]) -> Vec<F128> {
        assert_eq!(samples.len(), SAMPLES);
        let f = field();
        let mut h_values = vec![[0u8; COORDINATES]; QUOTIENTS];
        for (i, (h_value, weights)) in h_values.iter_mut().zip(&self.h_on_lambda).enumerate() {
            let mut c_value = [0u8; COORDINATES];
            for (&weight, column) in weights.iter().zip(&samples[..KAPPA]) {
                for (output, &coordinate) in c_value.iter_mut().zip(column) {
                    *output ^= f.mul(weight, coordinate);
                }
            }
            for (coordinate, output) in h_value.iter_mut().enumerate() {
                *output = f.mul(
                    samples[KAPPA + i][coordinate] ^ c_value[coordinate],
                    self.psi_inverse_on_lambda[i],
                );
            }
        }
        let mut coefficients = vec![[0u8; COORDINATES]; QUOTIENTS];
        for (value, basis) in h_values.iter().zip(&self.lambda_basis) {
            for (coefficient, &weight) in coefficients.iter_mut().zip(basis) {
                for (output, &coordinate) in coefficient.iter_mut().zip(value) {
                    *output ^= f.mul(weight, coordinate);
                }
            }
        }
        coefficients
            .iter()
            .map(|coefficient| f.compose(coefficient))
            .collect()
    }

    /// Portable byte lookup path; witness bit j is coefficient j's H value.
    pub(crate) fn eval_row(&self, row: &[u8; COORDINATES]) -> [u8; SAMPLES] {
        let mut samples = [0u8; SAMPLES];
        copy_h_values(row, &mut samples);
        for (chunk, &byte) in row.iter().enumerate() {
            let table = &self.row_tables[chunk * 256 + byte as usize];
            for (output, &value) in samples[KAPPA..].iter_mut().zip(table) {
                *output ^= value;
            }
        }
        samples
    }

    /// Reuse Flock's compressed continuation table and native dispatch.
    /// Its final point is 255; that point is outside our 255-sample domain.
    pub(crate) fn eval_row_native(&self, row: &[u8; COORDINATES]) -> [u8; SAMPLES] {
        let mut continuation = [F8::ZERO; KAPPA];
        self.native_table.apply(row, &mut continuation);
        let mut samples = [0u8; SAMPLES];
        copy_h_values(row, &mut samples);
        for (output, value) in samples[KAPPA..].iter_mut().zip(continuation) {
            *output = value.0;
        }
        samples
    }
}

fn copy_h_values(row: &[u8; COORDINATES], samples: &mut [u8; SAMPLES]) {
    for (i, output) in samples[..KAPPA].iter_mut().enumerate() {
        *output = (row[i / 8] >> (i % 8)) & 1;
    }
}

fn evaluate(coefficients: &[u8], x: u8) -> u8 {
    let f = field();
    coefficients
        .iter()
        .rev()
        .fold(0, |value, &c| f.mul(value, x) ^ c)
}

fn vanishing_polynomial(nodes: &[u8]) -> Vec<u8> {
    let f = field();
    let mut polynomial = vec![1];
    for &node in nodes {
        let mut next = vec![0; polynomial.len() + 1];
        for (i, &coefficient) in polynomial.iter().enumerate() {
            next[i] ^= f.mul(node, coefficient);
            next[i + 1] ^= coefficient;
        }
        polynomial = next;
    }
    polynomial
}

fn lagrange_basis(nodes: &[u8]) -> (Vec<Vec<u8>>, Vec<u8>) {
    let f = field();
    let polynomial = vanishing_polynomial(nodes);
    let n = nodes.len();
    let mut bases = Vec::with_capacity(n);
    let mut inverses = Vec::with_capacity(n);
    for &node in nodes {
        let mut quotient = vec![0; n];
        quotient[n - 1] = polynomial[n];
        for i in (1..n).rev() {
            quotient[i - 1] = polynomial[i] ^ f.mul(node, quotient[i]);
        }
        let denominator = evaluate(&quotient, node);
        assert_ne!(denominator, 0, "interpolation nodes must be distinct");
        let inverse = f.inv(denominator);
        for coefficient in &mut quotient {
            *coefficient = f.mul(*coefficient, inverse);
        }
        inverses.push(inverse);
        bases.push(quotient);
    }
    (bases, inverses)
}

#[cfg(test)]
mod tests {
    use super::*;
    use flock_field::{phi8, test_rng::Rng};

    fn oracle_evaluate(polynomial: &[F8], x: F8) -> F8 {
        polynomial.iter().rev().fold(F8::ZERO, |v, &c| v * x + c)
    }

    fn oracle_multiply(left: &[F8], right: &[F8]) -> Vec<F8> {
        let mut product = vec![F8::ZERO; left.len() + right.len() - 1];
        for (i, &a) in left.iter().enumerate() {
            for (j, &b) in right.iter().enumerate() {
                product[i + j] += a * b;
            }
        }
        product
    }

    // Independent incremental Newton interpolation, using F8 arithmetic
    // rather than the production multiplication and Lagrange tables.
    fn oracle_interpolate(values: &[F8]) -> Vec<F8> {
        let mut polynomial = vec![F8::ZERO; values.len()];
        let mut basis = vec![F8::ONE];
        for (i, &value) in values.iter().enumerate() {
            let node = F8(i as u8);
            let scale =
                (value + oracle_evaluate(&polynomial, node)) * oracle_evaluate(&basis, node).inv();
            for (output, &coefficient) in polynomial.iter_mut().zip(&basis) {
                *output += scale * coefficient;
            }
            basis = oracle_multiply(&basis, &[node, F8::ONE]);
        }
        polynomial
    }

    fn oracle_row(row: &[u8; COORDINATES]) -> Vec<F8> {
        oracle_interpolate(
            &(0..KAPPA)
                .map(|i| F8((row[i / 8] >> (i % 8)) & 1))
                .collect::<Vec<_>>(),
        )
    }

    #[test]
    fn row_tables_and_native_continuation_match_newton_oracle() {
        let d = domain();
        let mut rng = Rng::new(0x2551_2812);
        let mut rows = vec![[0; COORDINATES], [255; COORDINATES]];
        for i in [0, 7, 8, 63, 64, 119, 127] {
            let mut row = [0; COORDINATES];
            row[i / 8] = 1 << (i % 8);
            rows.push(row);
        }
        for _ in 0..4 {
            let mut row = [0; COORDINATES];
            rng.fill_bytes(&mut row);
            rows.push(row);
        }
        for row in rows {
            let polynomial = oracle_row(&row);
            let expected: [u8; SAMPLES] =
                std::array::from_fn(|i| oracle_evaluate(&polynomial, F8(i as u8)).0);
            assert_eq!(d.eval_row(&row), expected);
            assert_eq!(d.eval_row_native(&row), expected);
        }
    }

    #[test]
    fn extension_lagrange_weights_match_independent_polynomial() {
        let d = domain();
        let mut rng = Rng::new(0x1281_2716);
        let mut row = [0; COORDINATES];
        rng.fill_bytes(&mut row);
        let polynomial = oracle_row(&row);
        let mut points: Vec<_> = (0..256).map(|i| phi8(F8(i as u8))).collect();
        points.extend([rng.f128(), rng.f128()]);
        let psi = (0..KAPPA).fold(vec![F8::ONE], |p, i| {
            oracle_multiply(&p, &[F8(i as u8), F8::ONE])
        });
        for (index, x) in points.into_iter().enumerate() {
            let weights = d.lagrange_at(x);
            assert_eq!(
                weights.iter().copied().fold(F128::ZERO, |a, b| a + b),
                F128::ONE
            );
            let actual = weights.iter().enumerate().fold(F128::ZERO, |sum, (i, &w)| {
                if (row[i / 8] >> (i % 8)) & 1 == 1 {
                    sum + w
                } else {
                    sum
                }
            });
            let expected = polynomial
                .iter()
                .rev()
                .fold(F128::ZERO, |v, &c| v * x + phi8(c));
            assert_eq!(actual, expected);
            let expected_psi = psi.iter().rev().fold(F128::ZERO, |v, &c| v * x + phi8(c));
            assert_eq!(d.vanishing_at(x), expected_psi);
            assert_eq!(d.contains(x), index < KAPPA);
            if index < KAPPA {
                for (i, weight) in weights.into_iter().enumerate() {
                    assert_eq!(weight, if i == index { F128::ONE } else { F128::ZERO });
                }
            }
        }
    }

    #[test]
    fn quotient_matches_direct_polynomial_product_and_long_division() {
        let d = domain();
        let f = field();
        let mut rng = Rng::new(0x2551_2716);
        let mut samples = vec![[0u8; COORDINATES]; SAMPLES];
        let mut expected = vec![F128::ZERO; QUOTIENTS];
        let psi = (0..KAPPA).fold(vec![F8::ONE], |p, i| {
            oracle_multiply(&p, &[F8(i as u8), F8::ONE])
        });
        assert_eq!(d.quotient(&samples), expected);
        for _ in 0..3 {
            let mut a = [0; COORDINATES];
            let mut b = [0; COORDINATES];
            rng.fill_bytes(&mut a);
            rng.fill_bytes(&mut b);
            let weight = rng.f128();
            let coordinates = f.decompose(weight);
            let a_samples = d.eval_row(&a);
            let b_samples = d.eval_row_native(&b);
            for ((sample, a), b) in samples.iter_mut().zip(a_samples).zip(b_samples) {
                let product = F8(a) * F8(b);
                for (output, &coordinate) in sample.iter_mut().zip(&coordinates) {
                    *output ^= (product * F8(coordinate)).0;
                }
            }
            let a_poly = oracle_row(&a);
            let b_poly = oracle_row(&b);
            let c: [u8; COORDINATES] = std::array::from_fn(|i| a[i] & b[i]);
            let c_poly = oracle_row(&c);
            let mut residual = oracle_multiply(&a_poly, &b_poly);
            for (output, &coefficient) in residual.iter_mut().zip(&c_poly) {
                *output += coefficient;
            }
            for degree in (KAPPA..SAMPLES).rev() {
                let coefficient = residual[degree];
                expected[degree - KAPPA] += weight * phi8(coefficient);
                for (i, &divisor) in psi.iter().enumerate() {
                    residual[degree - KAPPA + i] += coefficient * divisor;
                }
            }
            assert!(residual.iter().all(|&c| c == F8::ZERO));
            assert_eq!(d.quotient(&samples), expected);
        }
    }
}
