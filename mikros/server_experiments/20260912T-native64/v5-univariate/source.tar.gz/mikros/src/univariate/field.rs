//! Intermediate-field arithmetic for `latex/4-block.tex`.
//!
//! `K = GF(256)` uses Flock's AES representation and its `PHI_8_TABLE`
//! embedding into the GHASH field `E = GF(2^128)`. An element of `E` is
//! represented over `K` in the basis `eta_j = x^j`, for `0 <= j < 16`.
//! These coordinates are **not** the sixteen bytes of a GHASH element.
//!
//! Initialization checks that the 128 binary vectors
//! `eta_j * embed(1 << t)` form a basis. Gaussian elimination constructs the
//! inverse change of basis; byte lookup tables then perform both conversions
//! using sixteen lookups and XORs. Together with the actual 256-by-256
//! multiplication table, these reusable tables occupy about 192 KiB.

use std::sync::OnceLock;

use flock_field::{F8, F128, PHI_8_TABLE};

const COORDINATES: usize = 16;
const BINARY_DIMENSION: usize = 128;
const FIELD_SIZE: usize = 256;

type ByteTables = Box<[[u128; FIELD_SIZE]]>;

/// Shared arithmetic and basis maps for the intermediate field `GF(256)`.
pub(crate) struct SmallField {
    multiplication: Box<[u8]>,
    inverse: [u8; FIELD_SIZE],
    to_coordinates: ByteTables,
    to_ghash: ByteTables,
}

/// Returns the process-wide, lazily initialized intermediate-field tables.
pub(crate) fn field() -> &'static SmallField {
    static FIELD: OnceLock<SmallField> = OnceLock::new();
    FIELD.get_or_init(SmallField::new)
}

impl SmallField {
    fn new() -> Self {
        let mut multiplication = vec![0; FIELD_SIZE * FIELD_SIZE].into_boxed_slice();
        let mut inverse = [0; FIELD_SIZE];
        for a in 0..FIELD_SIZE {
            inverse[a] = F8(a as u8).inv().0;
            for b in 0..FIELD_SIZE {
                multiplication[a * FIELD_SIZE + b] = (F8(a as u8) * F8(b as u8)).0;
            }
        }

        // Column 8*j+t maps bit t of K-coordinate j to GHASH binary bits.
        // Powers x^j with j < 16 need no reduction in the GHASH polynomial.
        let mut columns = [0u128; BINARY_DIMENSION];
        for j in 0..COORDINATES {
            let eta = F128::new(1u64 << j, 0);
            for t in 0..8 {
                columns[8 * j + t] = ghash_bits(eta * PHI_8_TABLE[1 << t]);
            }
        }
        let inverse_columns = invert_binary_basis(&columns);

        Self {
            multiplication,
            inverse,
            to_coordinates: byte_tables(&inverse_columns),
            to_ghash: byte_tables(&columns),
        }
    }

    /// Multiplies two AES-representation `GF(256)` elements by table lookup.
    #[inline]
    pub(crate) fn mul(&self, a: u8, b: u8) -> u8 {
        self.multiplication[usize::from(a) * FIELD_SIZE + usize::from(b)]
    }

    /// Returns the multiplicative inverse of a nonzero element.
    ///
    /// As in `F8::inv`, zero maps to zero. Callers performing division must
    /// independently ensure their denominator is nonzero.
    #[inline]
    pub(crate) fn inv(&self, a: u8) -> u8 {
        self.inverse[usize::from(a)]
    }

    /// Embeds an AES-representation `GF(256)` element into GHASH.
    #[inline]
    pub(crate) fn embed(&self, a: u8) -> F128 {
        PHI_8_TABLE[usize::from(a)]
    }

    /// Finds the unique coordinates `a_j` such that `value = sum_j embed(a_j) x^j`.
    #[inline]
    pub(crate) fn decompose(&self, value: F128) -> [u8; COORDINATES] {
        apply_byte_tables(&self.to_coordinates, &ghash_bits(value).to_le_bytes()).to_le_bytes()
    }

    /// Computes `sum_j embed(coordinates[j]) x^j` in the GHASH field.
    #[inline]
    pub(crate) fn compose(&self, coordinates: &[u8; COORDINATES]) -> F128 {
        from_ghash_bits(apply_byte_tables(&self.to_ghash, coordinates))
    }
}

#[inline]
fn ghash_bits(value: F128) -> u128 {
    u128::from(value.lo) | (u128::from(value.hi) << 64)
}

#[inline]
fn from_ghash_bits(value: u128) -> F128 {
    F128::new(value as u64, (value >> 64) as u64)
}

/// Inverts a binary matrix specified by columns, returning inverse columns.
fn invert_binary_basis(columns: &[u128; BINARY_DIMENSION]) -> [u128; BINARY_DIMENSION] {
    let mut rows = [0u128; BINARY_DIMENSION];
    let mut inverse_rows = [0u128; BINARY_DIMENSION];
    for r in 0..BINARY_DIMENSION {
        inverse_rows[r] = 1u128 << r;
        for (c, column) in columns.iter().enumerate() {
            rows[r] |= ((column >> r) & 1) << c;
        }
    }

    // Reduce [M | I] to [I | M^-1], checking full rank even in release builds.
    for c in 0..BINARY_DIMENSION {
        let pivot = (c..BINARY_DIMENSION)
            .find(|&r| (rows[r] >> c) & 1 != 0)
            .expect("GHASH powers x^0..x^15 must form a full-rank GF(256) basis");
        rows.swap(c, pivot);
        inverse_rows.swap(c, pivot);
        let pivot_row = rows[c];
        let pivot_inverse = inverse_rows[c];
        for r in 0..BINARY_DIMENSION {
            if r != c && (rows[r] >> c) & 1 != 0 {
                rows[r] ^= pivot_row;
                inverse_rows[r] ^= pivot_inverse;
            }
        }
    }

    let mut inverse_columns = [0u128; BINARY_DIMENSION];
    for (c, column) in inverse_columns.iter_mut().enumerate() {
        for (r, row) in inverse_rows.iter().enumerate() {
            *column |= ((row >> c) & 1) << r;
        }
    }
    inverse_columns
}

fn byte_tables(columns: &[u128; BINARY_DIMENSION]) -> ByteTables {
    // Allocate each 64 KiB map on the heap, avoiding a large stack temporary.
    let mut tables = vec![[0u128; FIELD_SIZE]; COORDINATES].into_boxed_slice();
    for j in 0..COORDINATES {
        for byte in 1usize..FIELD_SIZE {
            let bit = byte.trailing_zeros() as usize;
            tables[j][byte] = tables[j][byte & (byte - 1)] ^ columns[8 * j + bit];
        }
    }
    tables
}

#[inline]
fn apply_byte_tables(tables: &[[u128; FIELD_SIZE]], input: &[u8; COORDINATES]) -> u128 {
    let mut output = 0;
    for j in 0..COORDINATES {
        output ^= tables[j][usize::from(input[j])];
    }
    output
}

#[cfg(test)]
mod tests {
    use flock_field::{F8, F128, test_rng::Rng};

    use super::{COORDINATES, field, from_ghash_bits};

    fn compose_direct(coordinates: &[u8; COORDINATES]) -> F128 {
        coordinates
            .iter()
            .enumerate()
            .fold(F128::ZERO, |sum, (j, &coordinate)| {
                sum + field().embed(coordinate) * F128::new(1u64 << j, 0)
            })
    }

    #[test]
    fn small_field_all_products_match_f8() {
        let k = field();
        assert_eq!(k.multiplication.len(), 65536);
        for a in 0u16..256 {
            for b in 0u16..256 {
                assert_eq!(k.mul(a as u8, b as u8), (F8(a as u8) * F8(b as u8)).0);
            }
        }
        assert_eq!(k.inv(0), 0);
        for a in 1u16..256 {
            assert_eq!(k.inv(a as u8), F8(a as u8).inv().0);
            assert_eq!(k.mul(a as u8, k.inv(a as u8)), 1);
        }
        assert!(std::ptr::eq(k, field()));
    }

    #[test]
    fn small_field_binary_bases_roundtrip() {
        let k = field();
        assert_eq!(k.decompose(F128::ZERO), [0; COORDINATES]);
        assert_eq!(k.compose(&[0; COORDINATES]), F128::ZERO);
        for bit in 0..128 {
            let value = from_ghash_bits(1u128 << bit);
            let coordinates = k.decompose(value);
            assert_eq!(k.compose(&coordinates), value, "GHASH basis bit {bit}");
            assert_eq!(compose_direct(&coordinates), value, "GHASH basis bit {bit}");

            let mut coordinates = [0; COORDINATES];
            coordinates[bit / 8] = 1 << (bit % 8);
            let value = k.compose(&coordinates);
            assert_eq!(value, compose_direct(&coordinates), "K basis bit {bit}");
            assert_eq!(k.decompose(value), coordinates, "K basis bit {bit}");
        }
    }

    #[test]
    fn small_field_coordinates_use_embedding_not_raw_ghash_bytes() {
        let k = field();
        for a in 0u16..256 {
            let mut coordinates = [0; COORDINATES];
            coordinates[0] = a as u8;
            assert_eq!(k.decompose(k.embed(a as u8)), coordinates);
            assert_eq!(k.compose(&coordinates), k.embed(a as u8));
        }
        let mut x_coordinates = [0; COORDINATES];
        x_coordinates[1] = 1;
        assert_eq!(k.decompose(F128::new(2, 0)), x_coordinates);
        assert_ne!(k.embed(2), F128::new(2, 0));
    }

    #[test]
    fn small_field_random_roundtrip() {
        let k = field();
        let mut rng = Rng::new(0x5a17_8fbc_23e9_6140);
        for _ in 0..256 {
            let value = rng.f128();
            let coordinates = k.decompose(value);
            assert_eq!(k.compose(&coordinates), value);
            assert_eq!(compose_direct(&coordinates), value);

            let mut coordinates = [0; COORDINATES];
            rng.fill_bytes(&mut coordinates);
            let value = k.compose(&coordinates);
            assert_eq!(k.decompose(value), coordinates);
            assert_eq!(value, compose_direct(&coordinates));
        }
    }

    #[test]
    fn small_field_coordinate_scaling_matches_extension_multiplication() {
        let k = field();
        let mut rng = Rng::new(0x29f8_c1a4_708e_365b);
        for _ in 0..32 {
            let mut coordinates = [0; COORDINATES];
            rng.fill_bytes(&mut coordinates);
            let value = k.compose(&coordinates);
            for scalar in 0u16..256 {
                let scalar = scalar as u8;
                let scaled = coordinates.map(|coordinate| k.mul(coordinate, scalar));
                assert_eq!(k.compose(&scaled), k.embed(scalar) * value);
                assert_eq!(k.decompose(k.embed(scalar) * value), scaled);
            }
        }
    }
}
