//! GFNI evaluates arbitrary subset-XOR maps; no small-field weight assumption.
//!
//! Eight bit masks (one u64 per coefficient) are byte-transposed so each qword
//! contains the same row stripe for all eight coefficients. One affine GFNI
//! instruction then evaluates eight distinct 8-to-8 binary linear maps, each
//! on eight inputs. XOR across stripes gives eight coefficient bytes. Sixteen
//! such instructions produce all 128 field bits, with just 1 KiB of matrices.

use core::arch::x86_64::{
    __m512i, _mm_cvtsi128_si64, _mm_srli_si128, _mm_xor_si128, _mm256_castsi256_si128,
    _mm256_extracti128_si256, _mm256_xor_si256, _mm512_castsi512_si256, _mm512_extracti64x4_epi64,
    _mm512_gf2p8affine_epi64_epi8, _mm512_loadu_si512, _mm512_permutex2var_epi8,
    _mm512_permutexvar_epi8, _mm512_set1_epi64, _mm512_storeu_si512,
};

use flock_field::F128;

use super::{COEFFICIENTS, WIDE_BLOCK_BYTES, WIDE_LANES, stream_128, transpose_rows64, transpose8};

const PLANE_STRIDE: usize = COEFFICIENTS.next_multiple_of(8);
type Matrices = [[u64; 8]; 16];

pub(super) fn available() -> bool {
    std::is_x86_feature_detected!("gfni")
        && std::is_x86_feature_detected!("avx512f")
        && std::is_x86_feature_detected!("avx512bw")
        && std::is_x86_feature_detected!("avx512vbmi")
}

const fn byte_transpose_indices() -> [u8; 64] {
    let mut indices = [0; 64];
    let mut index = 0;
    while index < 64 {
        indices[index] = ((index % 8) * 8 + index / 8) as u8;
        index += 1;
    }
    indices
}

const BYTE_TRANSPOSE: [u8; 64] = byte_transpose_indices();

const fn row_gather_indices(high: bool) -> [u8; 64] {
    let mut indices = [0; 64];
    let mut index = 0;
    while index < 64 {
        // GFNI matrix rows are numbered from the highest byte to the lowest.
        indices[index] = ((7 - index % 8) * 16 + index / 8 + if high { 8 } else { 0 }) as u8;
        index += 1;
    }
    indices
}

const GATHER_LOW: [u8; 64] = row_gather_indices(false);
const GATHER_HIGH: [u8; 64] = row_gather_indices(true);

fn affine_matrices(weights: &[F128]) -> Matrices {
    debug_assert!(weights.len() <= WIDE_LANES);
    let mut matrices = [[0; 8]; 16];
    for (byte, output) in matrices.iter_mut().enumerate() {
        for (stripe, matrix) in output.iter_mut().enumerate() {
            let mut rows = 0u64;
            for lane in 0..8 {
                let value = weights
                    .get(stripe * 8 + lane)
                    .copied()
                    .unwrap_or(F128::ZERO);
                let word = if byte < 8 { value.lo } else { value.hi };
                rows |= ((word >> ((byte % 8) * 8)) & 0xff) << (lane * 8);
            }
            // Input-bit columns become output-bit rows. Reverse the matrix
            // row bytes to match Intel GFNI's affine instruction convention.
            *matrix = transpose8(rows).swap_bytes();
        }
    }
    matrices
}

/// # Safety
/// Requires GFNI, AVX-512F/BW/VBMI. Loads cover eight complete 128-byte stripes;
/// partial blocks are handled by the portable transpose before any raw load.
#[target_feature(enable = "gfni,avx512f,avx512bw,avx512vbmi")]
unsafe fn transpose_rows(input: &[u8]) -> [u64; 128] {
    if input.len() != WIDE_BLOCK_BYTES {
        return transpose_rows64(input);
    }
    // SAFETY: target features are declared above; each load/store is within
    // fixed-size arrays or the checked 1024-byte input.
    unsafe {
        let low_index = _mm512_loadu_si512(GATHER_LOW.as_ptr().cast());
        let high_index = _mm512_loadu_si512(GATHER_HIGH.as_ptr().cast());
        let transpose_index = _mm512_loadu_si512(BYTE_TRANSPOSE.as_ptr().cast());
        let basis = _mm512_set1_epi64(0x8040_2010_0804_0201u64 as i64);
        let mut tiles = [[0u64; 8]; 16];
        for stripe in 0..8 {
            let low = _mm512_loadu_si512(input.as_ptr().add(stripe * 128).cast());
            let high = _mm512_loadu_si512(input.as_ptr().add(stripe * 128 + 64).cast());
            let low = _mm512_gf2p8affine_epi64_epi8::<0>(
                basis,
                _mm512_permutex2var_epi8(low, low_index, high),
            );
            // Reloading input is unnecessary: the original registers are Copy.
            let original_low = _mm512_loadu_si512(input.as_ptr().add(stripe * 128).cast());
            let high = _mm512_gf2p8affine_epi64_epi8::<0>(
                basis,
                _mm512_permutex2var_epi8(original_low, high_index, high),
            );
            let mut low_words = [0u64; 8];
            let mut high_words = [0u64; 8];
            _mm512_storeu_si512(low_words.as_mut_ptr().cast(), low);
            _mm512_storeu_si512(high_words.as_mut_ptr().cast(), high);
            for byte in 0..8 {
                tiles[byte][stripe] = low_words[byte];
                tiles[byte + 8][stripe] = high_words[byte];
            }
        }
        let mut columns = [0; 128];
        for byte in 0..16 {
            let tile = _mm512_loadu_si512(tiles[byte].as_ptr().cast());
            let transposed = _mm512_permutexvar_epi8(transpose_index, tile);
            _mm512_storeu_si512(columns.as_mut_ptr().add(byte * 8).cast(), transposed);
        }
        columns
    }
}

#[inline]
#[target_feature(enable = "avx512f")]
unsafe fn xor_qwords(value: __m512i) -> u64 {
    let half = _mm256_xor_si256(
        _mm512_castsi512_si256(value),
        _mm512_extracti64x4_epi64::<1>(value),
    );
    let quarter = _mm_xor_si128(
        _mm256_castsi256_si128(half),
        _mm256_extracti128_si256::<1>(half),
    );
    _mm_cvtsi128_si64(_mm_xor_si128(quarter, _mm_srli_si128::<8>(quarter))) as u64
}

/// # Safety
/// Requires GFNI and AVX-512F/BW/VBMI. `offset` is a 27-element leaf start;
/// the five zero masks only XOR zero into the next leaf or padded plane tail.
#[inline]
#[target_feature(enable = "gfni,avx512f,avx512bw,avx512vbmi")]
unsafe fn consume(
    planes: &mut [[u8; PLANE_STRIDE]],
    matrices: &Matrices,
    offset: usize,
    masks: &[u64; 32],
) {
    debug_assert_eq!(planes.len(), 16);
    debug_assert!(offset + 32 <= PLANE_STRIDE);
    // SAFETY: four 64-byte mask loads and all 8-byte plane accesses stay in
    // checked fixed-size buffers. Matrix loads each cover exactly eight u64s.
    unsafe {
        let indices = _mm512_loadu_si512(BYTE_TRANSPOSE.as_ptr().cast());
        for group in 0..4 {
            let input = _mm512_loadu_si512(masks.as_ptr().add(group * 8).cast());
            let input = _mm512_permutexvar_epi8(indices, input);
            let start = offset + group * 8;
            for byte in 0..16 {
                let matrix = _mm512_loadu_si512(matrices[byte].as_ptr().cast());
                let contributions = _mm512_gf2p8affine_epi64_epi8::<0>(input, matrix);
                let value = xor_qwords(contributions);
                let old = u64::from_le_bytes(planes[byte][start..start + 8].try_into().unwrap());
                planes[byte][start..start + 8].copy_from_slice(&(old ^ value).to_le_bytes());
            }
        }
    }
}

pub(super) fn aggregate_chunk(a: &[u8], b: &[u8], weights: &[F128]) -> Vec<F128> {
    // SAFETY: the sole production caller dispatches only after available().
    assert!(available());
    unsafe { aggregate_chunk_unchecked(a, b, weights) }
}

#[target_feature(enable = "gfni,avx512f,avx512bw,avx512vbmi")]
unsafe fn aggregate_chunk_unchecked(a: &[u8], b: &[u8], weights: &[F128]) -> Vec<F128> {
    let mut planes = vec![[0u8; PLANE_STRIDE]; 16];
    for ((a, b), weights) in a
        .chunks(WIDE_BLOCK_BYTES)
        .zip(b.chunks(WIDE_BLOCK_BYTES))
        .zip(weights.chunks(WIDE_LANES))
    {
        let matrices = affine_matrices(weights);
        // SAFETY: features are declared by this function, and transpose_rows
        // handles partial blocks. stream_128 emits only valid 27-element leaves.
        unsafe {
            stream_128(
                &transpose_rows(a),
                &transpose_rows(b),
                0,
                &mut |offset, masks| {
                    consume(&mut planes, &matrices, offset, masks);
                },
            );
        }
    }
    (0..COEFFICIENTS)
        .map(|index| {
            let lo = u64::from_le_bytes(std::array::from_fn(|byte| planes[byte][index]));
            let hi = u64::from_le_bytes(std::array::from_fn(|byte| planes[byte + 8][index]));
            F128 { lo, hi }
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::{PLANE_STRIDE, affine_matrices, available, consume, transpose_rows};
    use crate::tensor::packed::{WIDE_BLOCK_BYTES, transpose_rows64};
    use flock_field::{F128, test_rng::Rng};

    #[test]
    fn affine_matrix_encoding_matches_every_subset_of_arbitrary_weights() {
        let mut rng = Rng::new(0x6F_41_AFF1);
        for rows in [0, 1, 7, 8, 9, 31, 63, 64] {
            let weights = rng.f128_vec(rows);
            let matrices = affine_matrices(&weights);
            for stripe in 0..8 {
                for mask in 0..256u64 {
                    let expected = (0..8).filter(|&lane| mask >> lane & 1 != 0).fold(
                        F128::ZERO,
                        |sum, lane| {
                            sum + weights
                                .get(stripe * 8 + lane)
                                .copied()
                                .unwrap_or(F128::ZERO)
                        },
                    );
                    for (byte, stripe_matrices) in matrices.iter().enumerate() {
                        let matrix = stripe_matrices[stripe];
                        let actual = (0..8).fold(0u8, |value, bit| {
                            value
                                | ((((matrix >> ((7 - bit) * 8)) & mask).count_ones() as u8 & 1)
                                    << bit)
                        });
                        let expected_word = if byte < 8 { expected.lo } else { expected.hi };
                        assert_eq!(actual, (expected_word >> ((byte % 8) * 8)) as u8);
                    }
                }
            }
        }
    }

    #[test]
    fn hardware_gfni_transpose_matches_all_basis_bits_and_partial_rows() {
        if !available() {
            return;
        }
        let mut input = [0; WIDE_BLOCK_BYTES];
        for bit in 0..WIDE_BLOCK_BYTES * 8 {
            input[bit / 8] = 1 << (bit % 8);
            // SAFETY: this test checks every runtime feature before entry.
            let actual = unsafe { transpose_rows(&input) };
            assert_eq!(actual, transpose_rows64(&input), "bit={bit}");
            input[bit / 8] = 0;
        }
        let mut rng = Rng::new(0x6F_71_7A4A5);
        rng.fill_bytes(&mut input);
        for rows in 0..=64 {
            let input = &input[..rows * 16];
            assert_eq!(
                unsafe { transpose_rows(input) },
                transpose_rows64(input),
                "rows={rows}"
            );
        }
    }

    #[test]
    fn hardware_gfni_consumption_matches_all_masks_output_bits_and_padding() {
        if !available() {
            return;
        }
        let mut rng = Rng::new(0x6F_71_C05);
        for rows in [0, 1, 7, 8, 9, 63, 64] {
            let weights = rng.f128_vec(rows);
            let matrices = affine_matrices(&weights);
            for stripe in 0..8 {
                for base in (0..256).step_by(24) {
                    let mut masks = [0; 32];
                    for (index, mask) in masks[..27].iter_mut().enumerate() {
                        *mask = (((base + index) % 256) as u64) << (stripe * 8);
                    }
                    let mut planes = vec![[0xa5; PLANE_STRIDE]; 16];
                    // SAFETY: hardware feature check above, valid padded leaf.
                    unsafe { consume(&mut planes, &matrices, 2160, &masks) };
                    for (index, mask) in masks.into_iter().enumerate() {
                        let expected = weights
                            .iter()
                            .enumerate()
                            .filter(|(lane, _)| mask >> lane & 1 != 0)
                            .fold(F128::ZERO, |sum, (_, &weight)| sum + weight);
                        for byte in 0..16 {
                            let word = if byte < 8 { expected.lo } else { expected.hi };
                            assert_eq!(
                                planes[byte][2160 + index],
                                0xa5 ^ (word >> ((byte % 8) * 8)) as u8
                            );
                        }
                    }
                    assert!(
                        planes
                            .iter()
                            .all(|plane| plane[..2160].iter().all(|&byte| byte == 0xa5))
                    );
                }
            }
        }
    }
}
