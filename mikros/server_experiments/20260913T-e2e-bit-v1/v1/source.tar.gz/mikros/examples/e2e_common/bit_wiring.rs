//! Bit expansion of the production circuit's word copy constraints.
//!
//! Index `128 * word + bit` is natural little-bit-first packed storage.
//! A word orbit becomes 128 independent bit orbits. All returned PCS claims
//! address the FULL PADDED union witness, before dense-stack compaction.
//! Construction and 0/1 field conversion are challenge-independent offline
//! work. GKR, challenge-dependent gathers and PCS opening belong online.

use flock_core::{
    challenger::Challenger,
    circuit::{CellSlot, Circuit},
    pcs::functional::TensorClaim,
    product_gkr::{
        BatchedGrinding, ProductGkrBatchedProof, prove_batched_prepared_sigma_with_grinding,
        verify_batched_with_sigma_and_grinding,
    },
    zerocheck::univariate_skip::build_eq,
};
use flock_field::F128;
use rayon::prelude::{IntoParallelIterator, ParallelIterator};
use serde::{Deserialize, Serialize};

/// Offline representations of one fixed wiring witness and its public wiring.
pub struct BitWiringFixture {
    pub log_bits: usize,
    /// Natural packed bits; one F128 stores the raw bits of one cell word.
    pub packed: Vec<F128>,
    pub sigma: Vec<usize>,
    /// Baseline Flock expects one field element for each binary value.
    pub flock_values: Vec<F128>,
    /// Public sigma's field tags, prepared before the online timer.
    pub flock_sigma_tags: Vec<F128>,
}

impl BitWiringFixture {
    pub fn new(
        circuit: &Circuit,
        padded_witness: &[F128],
        public: &[F128],
    ) -> Result<Self, String> {
        let word_log = check_circuit(circuit, public)?;
        if padded_witness.len() != 1usize << word_log {
            return Err("wiring source must be the full padded union witness".into());
        }
        let cells = circuit.cells();
        let nu = cells.nu();
        let mask = (1usize << nu) - 1;
        let packed: Vec<F128> = (0..1usize << cells.mu())
            .into_par_iter()
            .map(|i| {
                let (slot, row) = (i >> nu, i & mask);
                match cells.slots()[slot] {
                    CellSlot::Gate { ty, .. } if row < circuit.counts()[ty] => {
                        padded_witness[cells.gate_word_addr(slot, row)]
                    }
                    CellSlot::Public { s } => {
                        public.get((s << nu) + row).copied().unwrap_or(F128::ZERO)
                    }
                    _ => F128::ZERO,
                }
            })
            .collect();
        let log_bits = cells.mu() + 7;
        let n = 1usize << log_bits;
        let sigma = prepare_sigma(circuit);
        let flock_sigma_tags = sigma.iter().map(|&i| F128::new(i as u64, 0)).collect();
        let flock_values = (0..n)
            .into_par_iter()
            .map(|i| {
                if bit(packed[i >> 7], i & 127) {
                    F128::ONE
                } else {
                    F128::ZERO
                }
            })
            .collect();
        Ok(Self {
            log_bits,
            packed,
            sigma,
            flock_values,
            flock_sigma_tags,
        })
    }
}

/// Verifier-key preprocessing; depends only on the public circuit.
pub fn prepare_sigma(circuit: &Circuit) -> Vec<usize> {
    (0..1usize << (circuit.cells().mu() + 7))
        .into_par_iter()
        .map(|i| (circuit.sigma()[i >> 7] << 7) | (i & 127))
        .collect()
}

/// Only values are proof messages. Query weights come from the verified PIOP
/// and the public circuit, never from a prover-supplied point.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct GatherProof {
    pub values: Vec<F128>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct FlockBitProof {
    pub gkr: ProductGkrBatchedProof,
    pub gather: GatherProof,
}

/// Turn an ordinary bit-MLE endpoint into the generalized PCS query type.
pub fn mle_query(rho: &[F128], value: F128) -> Result<TensorClaim, String> {
    if rho.len() < 7 {
        return Err("bit-MLE point needs at least seven coordinates".into());
    }
    Ok(TensorClaim {
        columns: build_eq(&rho[..7]),
        rows: pairs(&rho[7..]),
        value,
    })
}

/// Gather any tensor query over wiring bits into gate-slot queries on the
/// main witness. Arbitrary/non-normalized row factors are supported.
pub fn prove_gather(
    circuit: &Circuit,
    padded_witness: &[F128],
    public: &[F128],
    source: &TensorClaim,
) -> Result<(GatherProof, Vec<TensorClaim>), String> {
    let word_log = check_query(circuit, public, source)?;
    if padded_witness.len() != 1usize << word_log {
        return Err("gather source must be the full padded union witness".into());
    }
    let cells = circuit.cells();
    let values = (0..cells.num_gate_slots())
        .into_par_iter()
        .map(|slot| {
            let base = cells.gate_word_addr(slot, 0);
            (0..1usize << cells.nu())
                .map(|row| {
                    row_weight(&source.rows[..cells.nu()], row)
                        * word_dot(padded_witness[base + row], &source.columns)
                })
                .fold(F128::ZERO, |a, b| a + b)
        })
        .collect();
    let proof = GatherProof { values };
    let claims = verify_gather(circuit, public, source, &proof)?;
    Ok((proof, claims))
}

/// Verifier-only gather check. This function has NO witness parameter.
/// Returned claims must ALL be authenticated by the caller's PCS verifier.
pub fn verify_gather(
    circuit: &Circuit,
    public: &[F128],
    source: &TensorClaim,
    proof: &GatherProof,
) -> Result<Vec<TensorClaim>, String> {
    check_query(circuit, public, source)?;
    let cells = circuit.cells();
    let nu = cells.nu();
    if proof.values.len() != cells.num_gate_slots() {
        return Err("wrong number of bit wiring gather values".into());
    }
    let mut sum = F128::ZERO;
    let mut claims = Vec::with_capacity(proof.values.len());
    for (slot, descriptor) in cells.slots().iter().enumerate() {
        let slot_weight = row_weight(&source.rows[nu..], slot);
        match descriptor {
            CellSlot::Gate { .. } => {
                sum += slot_weight * proof.values[slot];
                // Extract only the fixed high address coordinates; the low nu
                // pairs retain the source functional exactly, normalized or not.
                let point = cells.gate_claim_point(slot, &vec![F128::ZERO; nu]);
                let mut rows = source.rows[..nu].to_vec();
                rows.extend(pairs(&point[nu..]));
                claims.push(TensorClaim {
                    columns: source.columns.clone(),
                    rows,
                    value: proof.values[slot],
                });
            }
            CellSlot::Public { s } => {
                let base = s << nu;
                for row in 0..(1usize << nu).min(public.len().saturating_sub(base)) {
                    sum += slot_weight
                        * row_weight(&source.rows[..nu], row)
                        * word_dot(public[base + row], &source.columns);
                }
            }
            CellSlot::Pad => {}
        }
    }
    if sum != source.value {
        return Err("bit wiring gather does not match PIOP endpoint".into());
    }
    Ok(claims)
}

/// Flock permutation baseline for the expanded bit relation. Caller binds the
/// circuit/public statement and main witness commitment before this entry.
pub fn prove_flock<C: Challenger>(
    circuit: &Circuit,
    offline: &BitWiringFixture,
    padded_witness: &[F128],
    public: &[F128],
    grinding: BatchedGrinding,
    ch: &mut C,
) -> Result<(FlockBitProof, Vec<TensorClaim>), String> {
    if offline.log_bits != circuit.cells().mu() + 7 {
        return Err("bit fixture dimension mismatch".into());
    }
    bind_bit_domain(offline.log_bits, ch);
    let (gkr, endpoint) = prove_batched_prepared_sigma_with_grinding(
        &offline.flock_values,
        &offline.flock_values,
        &offline.sigma,
        &offline.flock_sigma_tags,
        grinding,
        ch,
    );
    if endpoint.f_eval != endpoint.g_eval {
        return Err("Flock bit input evaluations disagree".into());
    }
    let source = mle_query(&endpoint.rho, endpoint.f_eval)?;
    let (gather, claims) = prove_gather(circuit, padded_witness, public, &source)?;
    Ok((FlockBitProof { gkr, gather }, claims))
}

/// Full PIOP replay with verifier-known bit sigma, followed by BOTH input
/// checks and gather reduction. No witness is read. PCS discharge is external.
pub fn verify_flock<C: Challenger>(
    circuit: &Circuit,
    bit_sigma: &[usize],
    public: &[F128],
    proof: &FlockBitProof,
    grinding: BatchedGrinding,
    ch: &mut C,
) -> Result<Vec<TensorClaim>, String> {
    let log_bits = circuit.cells().mu() + 7;
    if bit_sigma.len() != 1usize << log_bits {
        return Err("bit sigma dimension mismatch".into());
    }
    // The sigma is public verifier preprocessing; check against the circuit
    // before caching it in a VK. This helper does not accept proof-supplied sigma.
    bind_bit_domain(log_bits, ch);
    let endpoint =
        verify_batched_with_sigma_and_grinding(log_bits, &proof.gkr, bit_sigma, None, grinding, ch)
            .map_err(|e| format!("Flock bit permutation rejected: {e:?}"))?;
    if endpoint.f_eval != endpoint.g_eval {
        return Err("Flock bit g endpoint is unbound".into());
    }
    verify_gather(
        circuit,
        public,
        &mle_query(&endpoint.rho, endpoint.f_eval)?,
        &proof.gather,
    )
}

fn bind_bit_domain<C: Challenger>(log_bits: usize, ch: &mut C) {
    ch.observe_label(b"mikros-flock-e2e-bit-wiring-v1");
    ch.observe_bytes(&(log_bits as u64).to_le_bytes());
}

fn check_circuit(circuit: &Circuit, public: &[F128]) -> Result<usize, String> {
    if !circuit.check_public(public) || circuit.cells().num_gate_slots() == 0 {
        return Err(
            "bit wiring expects a valid circuit public segment and at least one gate slot".into(),
        );
    }
    let nu = circuit.cells().nu();
    Ok(circuit
        .cells()
        .gate_claim_point(0, &vec![F128::ZERO; nu])
        .len())
}

fn check_query(circuit: &Circuit, public: &[F128], source: &TensorClaim) -> Result<usize, String> {
    let word_log = check_circuit(circuit, public)?;
    if source.columns.len() != 128 || source.rows.len() != circuit.cells().mu() {
        return Err("malformed bit wiring tensor query".into());
    }
    Ok(word_log)
}

fn pairs(point: &[F128]) -> Vec<[F128; 2]> {
    point.iter().map(|&r| [F128::ONE + r, r]).collect()
}

fn row_weight(pairs: &[[F128; 2]], index: usize) -> F128 {
    pairs
        .iter()
        .enumerate()
        .fold(F128::ONE, |v, (k, pair)| v * pair[(index >> k) & 1])
}

fn word_dot(word: F128, columns: &[F128]) -> F128 {
    columns
        .iter()
        .enumerate()
        .filter_map(|(i, &w)| bit(word, i).then_some(w))
        .fold(F128::ZERO, |a, b| a + b)
}

fn bit(word: F128, index: usize) -> bool {
    ((if index < 64 { word.lo } else { word.hi }) >> (index & 63)) & 1 != 0
}

#[cfg(test)]
mod tests {
    use super::{
        BitWiringFixture, prove_flock, prove_gather, verify_flock, verify_gather, word_dot,
    };
    use crate::e2e_common::TreeFixture;
    use flock_core::{
        challenger::{Challenger, FsChallenger},
        pcs::functional::{TensorClaim, row_weights},
        product_gkr::{
            BatchedGrinding, prove_batched_prepared_sigma_with_grinding,
            prove_batched_with_grinding,
        },
        test_rng::Rng,
    };
    use flock_field::F128;

    #[test]
    fn prepared_sigma_preserves_gkr_proof() {
        let n = 128;
        let sigma: Vec<usize> = (0..n).map(|i| (17 * i + 3) % n).collect();
        let tags: Vec<F128> = sigma.iter().map(|&i| F128::new(i as u64, 0)).collect();
        let mut rng = Rng::new(0x2345);
        let f: Vec<F128> = (0..n)
            .map(|_| {
                if rng.next_u64() & 1 != 0 {
                    F128::ONE
                } else {
                    F128::ZERO
                }
            })
            .collect();
        let g: Vec<F128> = sigma.iter().map(|&i| f[i]).collect();
        let mut original = FsChallenger::new(b"prepared-sigma-equality");
        let mut prepared = FsChallenger::new(b"prepared-sigma-equality");
        let (p0, c0) = prove_batched_with_grinding(
            &f,
            &g,
            &sigma,
            None,
            BatchedGrinding::disabled(),
            &mut original,
        );
        let (p1, c1) = prove_batched_prepared_sigma_with_grinding(
            &f,
            &g,
            &sigma,
            &tags,
            BatchedGrinding::disabled(),
            &mut prepared,
        );
        assert_eq!(p0, p1);
        assert_eq!(c0.rho, c1.rho);
        assert_eq!(
            (c0.f_eval, c0.g_eval, c0.s_sigma_eval),
            (c1.f_eval, c1.g_eval, c1.s_sigma_eval)
        );
        assert_eq!(original.sample_f128(), prepared.sample_f128());
    }

    #[test]
    fn bit_expansion_and_general_gathers() {
        let fixture = TreeFixture::new(1);
        let witness = fixture.prepare_witness();
        let bits = BitWiringFixture::new(&fixture.circuit, &witness.0, &fixture.public).unwrap();
        for i in 0..bits.sigma.len() {
            assert_eq!(bits.sigma[i] & 127, i & 127);
            assert_eq!(bits.sigma[i] >> 7, fixture.circuit.sigma()[i >> 7]);
            assert_eq!(bits.flock_values[i], bits.flock_values[bits.sigma[i]]);
        }
        let mut rng = Rng::new(0x1234);
        let mut source = TensorClaim {
            columns: (0..128)
                .map(|_| F128::new(rng.next_u64(), rng.next_u64()))
                .collect(),
            rows: (0..fixture.circuit.cells().mu())
                .map(|_| {
                    [
                        F128::new(rng.next_u64(), rng.next_u64()),
                        F128::new(rng.next_u64(), rng.next_u64()),
                    ]
                })
                .collect(),
            value: F128::ZERO,
        };
        source.value = bits
            .packed
            .iter()
            .zip(row_weights(&source.rows))
            .map(|(&word, row)| row * word_dot(word, &source.columns))
            .fold(F128::ZERO, |a, b| a + b);
        let (proof, claims) =
            prove_gather(&fixture.circuit, &witness.0, &fixture.public, &source).unwrap();
        assert_eq!(
            claims,
            verify_gather(&fixture.circuit, &fixture.public, &source, &proof).unwrap()
        );
        for claim in &claims {
            let actual: F128 = witness
                .0
                .iter()
                .zip(row_weights(&claim.rows))
                .map(|(&word, row)| row * word_dot(word, &claim.columns))
                .fold(F128::ZERO, |a, b| a + b);
            assert_eq!(actual, claim.value);
        }
        let mut tampered = proof;
        tampered.values[0] += F128::ONE;
        assert!(verify_gather(&fixture.circuit, &fixture.public, &source, &tampered).is_err());
    }

    #[test]
    fn flock_bit_piop_replay_binds_both_sides() {
        let fixture = TreeFixture::new(1);
        let witness = fixture.prepare_witness();
        let bits = BitWiringFixture::new(&fixture.circuit, &witness.0, &fixture.public).unwrap();
        let mut prover = FsChallenger::new(b"bit-wiring-test");
        let (proof, claims) = prove_flock(
            &fixture.circuit,
            &bits,
            &witness.0,
            &fixture.public,
            BatchedGrinding::disabled(),
            &mut prover,
        )
        .unwrap();
        let mut verifier = FsChallenger::new(b"bit-wiring-test");
        assert_eq!(
            claims,
            verify_flock(
                &fixture.circuit,
                &bits.sigma,
                &fixture.public,
                &proof,
                BatchedGrinding::disabled(),
                &mut verifier
            )
            .unwrap()
        );
        assert_eq!(prover.sample_f128(), verifier.sample_f128());
        let mut bad = proof;
        bad.gkr.g_eval += F128::ONE;
        assert!(
            verify_flock(
                &fixture.circuit,
                &bits.sigma,
                &fixture.public,
                &bad,
                BatchedGrinding::disabled(),
                &mut FsChallenger::new(b"bit-wiring-test")
            )
            .is_err()
        );
    }
}
