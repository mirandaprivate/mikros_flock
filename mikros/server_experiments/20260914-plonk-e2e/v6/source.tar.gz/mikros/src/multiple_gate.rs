//! Gate sumcheck for packing 128 binary circuit executions across columns.
//!
//! The four wire vectors are `[L,R,M,O]`, with virtual `M` supplied by the
//! caller. The five binary selectors are `[L,R,M,O,C]`. This proves the
//! equality-weighted packed gate residual, and returns their nine evaluations
//! at one common, low-bit-first point. Authenticate the selectors and L/R/O
//! through the PCS and reduce M through the weighted Hadamard proof.
//!
//! Public selectors may repeat with any power-of-two period up to 128. This
//! representation is exact: selector state never expands to the full gate
//! count. The source commitment must bind the corresponding repeated columns.

use crate::{Error, inner_product};
use core::mem::MaybeUninit;
use flock_core::zerocheck::univariate_skip::SplitEqGhash;
use flock_field::{F128, F256Unreduced};
use flock_transcript::challenger::Challenger;
use rayon::prelude::*;
use serde::{Deserialize, Serialize};

/// One packed-bit period for each selector, in `[L,R,M,O,C]` order.
/// `period_log=0` is a constant selector; unused bits in its final byte must
/// be zero. The full source repeats this period until there are `2^log_n` gates.
#[derive(Clone, Debug, PartialEq, Eq)]
pub struct RepeatedSelectors {
    pub period_log: usize,
    pub packed: [Vec<u8>; 5],
}

/// A cubic round transmits `[g(0), coefficient(X^2), coefficient(X^3)]`.
/// Its linear coefficient follows from the running claim `g(0)+g(1)`.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Proof {
    pub rounds: Vec<[F128; 3]>,
    pub selectors: [F128; 5],
    pub wires: [F128; 4],
}

impl Proof {
    pub fn field_elements(&self) -> usize {
        3 * self.rounds.len() + 9
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub struct Claims {
    /// Common MLE point, in low-bit-first order.
    pub point: Vec<F128>,
    /// `[L,R,M,O,C]` selector evaluations, all requiring authentication.
    pub selectors: [F128; 5],
    /// `[L,R,M,O]` evaluations. M is the next weighted Hadamard scalar claim.
    pub wires: [F128; 4],
}

fn checked_len(log_n: usize, period_log: usize) -> Result<usize, Error> {
    if log_n >= usize::BITS as usize {
        return Err(Error::InvalidLogN(log_n));
    }
    let n = 1usize << log_n;
    if n > isize::MAX as usize / size_of::<F128>() {
        return Err(Error::InvalidLogN(log_n));
    }
    if period_log > 7 || period_log > log_n {
        return Err(Error::ProofShape("multiple gate selector period"));
    }
    Ok(n)
}

impl RepeatedSelectors {
    fn initial_state(&self, log_n: usize) -> Result<[Vec<F128>; 5], Error> {
        checked_len(log_n, self.period_log)?;
        let period = 1usize << self.period_log;
        let bytes = period.div_ceil(8);
        for input in &self.packed {
            if input.len() != bytes {
                return Err(Error::InputLength {
                    input: "selector period",
                    expected: bytes,
                    got: input.len(),
                });
            }
            if period < 8 && input[0] >> period != 0 {
                return Err(Error::ProofShape("noncanonical selector period"));
            }
        }
        Ok(std::array::from_fn(|j| {
            (0..period)
                .map(|i| {
                    if self.packed[j][i / 8] >> (i % 8) & 1 == 0 {
                        F128::ZERO
                    } else {
                        F128::ONE
                    }
                })
                .collect()
        }))
    }
}

fn start<C: Challenger>(
    log_n: usize,
    period_log: usize,
    basis_sum: F128,
    challenger: &mut C,
) -> Vec<F128> {
    challenger.observe_label(b"mikros-binary-multiple-instance-gates-v1");
    challenger.observe_bytes(&(log_n as u64).to_le_bytes());
    challenger.observe_bytes(&(period_log as u64).to_le_bytes());
    challenger.observe_bytes(&128u64.to_le_bytes());
    challenger.observe_f128(basis_sum);
    challenger.sample_f128_vec(log_n)
}

fn observe_terminals<C: Challenger>(proof: &Proof, challenger: &mut C) {
    challenger.observe_label(b"mikros-multiple-instance-gate-terminals-v1");
    challenger.observe_f128_slice(&proof.selectors);
    challenger.observe_f128_slice(&proof.wires);
}

fn residual(selectors: &[F128; 5], wires: &[F128; 4], basis_sum: F128) -> F128 {
    (0..4).fold(basis_sum * selectors[4], |sum, j| {
        sum + selectors[j] * wires[j]
    })
}

fn cubic([r0, r1, rinf]: [F128; 3], x: F128, prefix: F128) -> [F128; 3] {
    [
        prefix * (F128::ONE + x) * r0,
        prefix * (x * rinf + r0 + r1),
        prefix * rinf,
    ]
}

fn evaluate([g0, g2, g3]: [F128; 3], claim: F128, r: F128) -> F128 {
    g0 + r * (claim + g2 + g3 + r * (g2 + r * g3))
}

fn add(a: [F128; 3], b: [F128; 3]) -> [F128; 3] {
    std::array::from_fn(|j| a[j] + b[j])
}

/// The repeated selector depends only on low index bits. Put all of them in
/// eq.lo, and multiply each selector coefficient by that shared weight once
/// per round. High blocks reuse these small arrays, with no N-sized eq table.
struct RoundWeights {
    eq: SplitEqGhash,
    coefficients: [[Vec<F128>; 3]; 4],
    constant: [F128; 3],
}

impl RoundWeights {
    fn new(point: &[F128], selectors: &[Vec<F128>; 5], basis_sum: F128) -> Self {
        let period = selectors[0].len();
        let period_log = period.ilog2() as usize;
        let lo_log = point.len().div_ceil(2).max(period_log.saturating_sub(1));
        let eq = SplitEqGhash::with_n_hi(point, point.len() - lo_log);
        let mask = period - 1;
        let coefficients = std::array::from_fn(|j| {
            let mut result: [Vec<F128>; 3] =
                std::array::from_fn(|_| Vec::with_capacity(eq.lo.len()));
            for (i, &weight) in eq.lo.iter().enumerate() {
                let q0 = selectors[j][(2 * i) & mask];
                let q1 = selectors[j][(2 * i + 1) & mask];
                let a = weight * q0;
                let b = weight * q1;
                result[0].push(a);
                result[1].push(b);
                result[2].push(a + b);
            }
            for coefficient in &mut result {
                if coefficient.iter().all(|x| x.is_zero()) {
                    coefficient.clear();
                }
            }
            result
        });
        let mut constant = [F128::ZERO; 3];
        for (i, &weight) in eq.lo.iter().enumerate() {
            constant[0] += weight * selectors[4][(2 * i) & mask];
            constant[1] += weight * selectors[4][(2 * i + 1) & mask];
        }
        constant[0] *= basis_sum;
        constant[1] *= basis_sum;
        Self {
            eq,
            coefficients,
            constant,
        }
    }
}

fn message_block(
    wires: [&[F128]; 4],
    base: usize,
    weights: &[[Vec<F128>; 3]; 4],
    count: usize,
) -> [F128; 3] {
    let mut accum = [F256Unreduced::ZERO; 3];
    #[allow(unused_mut)]
    let mut cursor = 0;
    #[cfg(all(
        target_arch = "x86_64",
        target_feature = "avx512f",
        target_feature = "vpclmulqdq",
        target_feature = "sse4.1"
    ))]
    {
        use core::arch::x86_64::_mm512_xor_si512;
        use flock_field::gf2_128::x86_64::{WideGhashX4, f128x4_loadu, f128x4_set};
        // SAFETY: native features are compile-time gated. Each iteration has
        // four complete adjacent pairs and four in-bounds coefficient values.
        unsafe {
            let mut wide = [WideGhashX4::zero(); 3];
            let full = count / 4 * 4;
            for j in 0..4 {
                if weights[j].iter().all(Vec::is_empty) {
                    continue;
                }
                for i in (0..full).step_by(4) {
                    let input = &wires[j][2 * (base + i)..];
                    let even = f128x4_set(input[0], input[2], input[4], input[6]);
                    let odd = f128x4_set(input[1], input[3], input[5], input[7]);
                    let values = [even, odd, _mm512_xor_si512(even, odd)];
                    for k in 0..3 {
                        if !weights[j][k].is_empty() {
                            wide[k].mul_acc(values[k], f128x4_loadu(weights[j][k].as_ptr().add(i)));
                        }
                    }
                }
            }
            for k in 0..3 {
                accum[k] ^= wide[k].fold();
            }
            cursor = full;
        }
    }
    for j in 0..4 {
        for i in cursor..count {
            let a = wires[j][2 * (base + i)];
            let b = wires[j][2 * (base + i) + 1];
            for (k, value) in [a, b, a + b].into_iter().enumerate() {
                if !weights[j][k].is_empty() {
                    accum[k] ^= value.mul_unreduced(weights[j][k][i]);
                }
            }
        }
    }
    accum.map(F256Unreduced::reduce)
}

fn round_message(
    wires: [&[F128]; 4],
    point: &[F128],
    selectors: &[Vec<F128>; 5],
    basis_sum: F128,
) -> [F128; 3] {
    let weights = RoundWeights::new(point, selectors, basis_sum);
    assert_eq!(
        wires[0].len() / 2,
        weights.eq.lo.len() * weights.eq.hi.len()
    );
    let block = |hi: usize| {
        message_block(
            wires,
            hi * weights.eq.lo.len(),
            &weights.coefficients,
            weights.eq.lo.len(),
        )
        .map(|v| v * weights.eq.hi[hi])
    };
    let sums = if wires[0].len() >= 1 << 15 && rayon::current_num_threads() > 1 {
        (0..weights.eq.hi.len())
            .into_par_iter()
            .map(block)
            .reduce(|| [F128::ZERO; 3], add)
    } else {
        (0..weights.eq.hi.len())
            .map(block)
            .fold([F128::ZERO; 3], add)
    };
    // The high equality tensor sums to one. The public constant residual is
    // linear in the current selector variable, so its quadratic part is zero.
    add(sums, weights.constant)
}

fn fold_into(source: &[F128], challenge: F128, output: &mut Vec<F128>) {
    const CHUNK: usize = 1024;
    let len = source.len() / 2;
    let uninit = inner_product::prepare_output(output, len);
    let block = |(i, destination): (usize, &mut [MaybeUninit<F128>])| {
        // Reuse Flock's native pair-fold kernel on a bounded initialized tile.
        // This avoids a whole-array zeroing pass and keeps intermediate writes
        // in cache, without exposing uninitialized values as an F128 slice.
        let mut tile = [F128::ZERO; CHUNK];
        flock_field::f128_slice::fold_pairs(
            source,
            i * CHUNK,
            &mut tile[..destination.len()],
            challenge,
        );
        // SAFETY: source tile is initialized; destination has the same length,
        // is disjoint from tile, and this worker exclusively owns every slot.
        unsafe {
            std::ptr::copy_nonoverlapping(
                tile.as_ptr(),
                destination.as_mut_ptr().cast::<F128>(),
                destination.len(),
            );
        }
    };
    if source.len() >= 1 << 15 && rayon::current_num_threads() > 1 {
        uninit.par_chunks_mut(CHUNK).enumerate().for_each(block);
    } else {
        uninit.chunks_mut(CHUNK).enumerate().for_each(block);
    }
    // SAFETY: all output slots were initialized by joined, disjoint workers.
    unsafe { output.set_len(len) };
}

/// Prove gates for 128 executions. Here `log_n` counts gates PER execution,
/// and each element of a wire packs its 128 binary values in the fixed basis.
/// `basis_sum` is the sum of these 128 basis elements and is public input.
/// Source commitments and public I/O must be bound before calling this entry.
pub fn prove<C: Challenger>(
    wires: [&[F128]; 4],
    selectors: &RepeatedSelectors,
    log_n: usize,
    basis_sum: F128,
    challenger: &mut C,
) -> Result<(Proof, Claims), Error> {
    let n = checked_len(log_n, selectors.period_log)?;
    for wire in wires {
        if wire.len() != n {
            return Err(Error::InputLength {
                input: "packed gate wire",
                expected: n,
                got: wire.len(),
            });
        }
    }
    let mut selector_state = selectors.initial_state(log_n)?;
    let x = start(log_n, selectors.period_log, basis_sum, challenger);
    let mut point = Vec::with_capacity(log_n);
    let mut rounds = Vec::with_capacity(log_n);
    let mut claim = F128::ZERO;
    let mut prefix = F128::ONE;
    let mut state: [Vec<F128>; 4] = std::array::from_fn(|_| Vec::new());
    let mut next: [Vec<F128>; 4] = std::array::from_fn(|_| Vec::new());
    for i in 0..log_n {
        let current: [&[F128]; 4] = if i == 0 {
            wires
        } else {
            std::array::from_fn(|j| state[j].as_slice())
        };
        let core = round_message(current, &x[i + 1..], &selector_state, basis_sum);
        if prefix * ((F128::ONE + x[i]) * core[0] + x[i] * core[1]) != claim {
            return Err(Error::InnerProductMismatch);
        }
        let message = cubic(core, x[i], prefix);
        challenger.observe_f128_slice(&message);
        let r = challenger.sample_f128();
        claim = evaluate(message, claim, r);
        prefix *= F128::ONE + x[i] + r;
        for j in 0..4 {
            fold_into(current[j], r, &mut next[j]);
        }
        std::mem::swap(&mut state, &mut next);
        for selector in &mut selector_state {
            if selector.len() > 1 {
                flock_multilinear::fold_low(selector, r);
            }
        }
        rounds.push(message);
        point.push(r);
    }
    let proof = Proof {
        rounds,
        selectors: std::array::from_fn(|j| selector_state[j][0]),
        wires: std::array::from_fn(|j| if log_n == 0 { wires[j][0] } else { state[j][0] }),
    };
    observe_terminals(&proof, challenger);
    if claim != prefix * residual(&proof.selectors, &proof.wires, basis_sum) {
        return Err(Error::InnerProductMismatch);
    }
    let claims = Claims {
        point,
        selectors: proof.selectors,
        wires: proof.wires,
    };
    Ok((proof, claims))
}

/// Verify only the sumcheck and terminal gate relation. No original selector
/// or witness vector is accepted here: the caller must authenticate the claims
/// through its PCS and the virtual-product Hadamard reduction.
pub fn verify<C: Challenger>(
    proof: &Proof,
    log_n: usize,
    period_log: usize,
    basis_sum: F128,
    challenger: &mut C,
) -> Result<Claims, Error> {
    checked_len(log_n, period_log)?;
    if proof.rounds.len() != log_n {
        return Err(Error::ProofShape("multiple gate rounds"));
    }
    let x = start(log_n, period_log, basis_sum, challenger);
    let mut point = Vec::with_capacity(log_n);
    let mut claim = F128::ZERO;
    let mut equality = F128::ONE;
    for (i, &message) in proof.rounds.iter().enumerate() {
        challenger.observe_f128_slice(&message);
        let r = challenger.sample_f128();
        claim = evaluate(message, claim, r);
        equality *= F128::ONE + x[i] + r;
        point.push(r);
    }
    observe_terminals(proof, challenger);
    if claim != equality * residual(&proof.selectors, &proof.wires, basis_sum) {
        return Err(Error::InnerProductMismatch);
    }
    Ok(Claims {
        point,
        selectors: proof.selectors,
        wires: proof.wires,
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use flock_field::test_rng::Rng;
    use flock_transcript::challenger::FsChallenger;

    fn challenger() -> FsChallenger {
        FsChallenger::new(b"multiple-gate-tests-v1")
    }

    fn eq_index(point: &[F128], index: usize) -> F128 {
        point.iter().enumerate().fold(F128::ONE, |v, (i, &r)| {
            v * if index >> i & 1 == 0 {
                F128::ONE + r
            } else {
                r
            }
        })
    }

    fn source_value(source: &[F128], point: &[F128]) -> F128 {
        source
            .iter()
            .enumerate()
            .fold(F128::ZERO, |v, (i, &a)| v + a * eq_index(point, i))
    }

    fn selector_bit(selectors: &RepeatedSelectors, j: usize, gate: usize) -> F128 {
        let i = gate & ((1 << selectors.period_log) - 1);
        if selectors.packed[j][i / 8] >> (i % 8) & 1 == 0 {
            F128::ZERO
        } else {
            F128::ONE
        }
    }

    fn fixture(
        log_n: usize,
        period_log: usize,
        rng: &mut Rng,
    ) -> (RepeatedSelectors, [Vec<F128>; 4], F128) {
        let period = 1usize << period_log;
        let mut selectors = RepeatedSelectors {
            period_log,
            packed: std::array::from_fn(|_| vec![0; period.div_ceil(8)]),
        };
        for i in 0..period {
            for j in 0..5 {
                if j == 3 || rng.bit() {
                    selectors.packed[j][i / 8] |= 1 << (i % 8);
                }
            }
        }
        let n = 1usize << log_n;
        let l = rng.f128_vec(n);
        let r = rng.f128_vec(n);
        let m: Vec<_> = l
            .iter()
            .zip(&r)
            .map(|(a, b)| F128::new(a.lo & b.lo, a.hi & b.hi))
            .collect();
        let basis_sum = F128::new(u64::MAX, u64::MAX);
        let o = (0..n)
            .map(|i| {
                selector_bit(&selectors, 0, i) * l[i]
                    + selector_bit(&selectors, 1, i) * r[i]
                    + selector_bit(&selectors, 2, i) * m[i]
                    + selector_bit(&selectors, 4, i) * basis_sum
            })
            .collect();
        (selectors, [l, r, m, o], basis_sum)
    }

    fn assert_sources(selectors: &RepeatedSelectors, wires: &[Vec<F128>; 4], claims: &Claims) {
        for j in 0..4 {
            assert_eq!(source_value(&wires[j], &claims.point), claims.wires[j]);
        }
        for j in 0..5 {
            let value = (0..wires[0].len()).fold(F128::ZERO, |v, i| {
                v + selector_bit(selectors, j, i) * eq_index(&claims.point, i)
            });
            assert_eq!(value, claims.selectors[j]);
        }
    }

    #[test]
    fn arbitrary_repeated_binary_selectors_match_all_nine_source_oracles() {
        let mut rng = Rng::new(0x5E1_EC702);
        for (log_n, period_log) in [(0, 0), (1, 0), (1, 1), (7, 7), (10, 1), (10, 7)] {
            let (selectors, wires, basis_sum) = fixture(log_n, period_log, &mut rng);
            let mut prover = challenger();
            let (proof, claims) = prove(
                wires.each_ref().map(Vec::as_slice),
                &selectors,
                log_n,
                basis_sum,
                &mut prover,
            )
            .unwrap();
            assert_eq!(proof.field_elements(), 3 * log_n + 9);
            let mut verifier = challenger();
            assert_eq!(
                verify(&proof, log_n, period_log, basis_sum, &mut verifier).unwrap(),
                claims
            );
            assert_eq!(prover.sample_f128(), verifier.sample_f128());
            assert_sources(&selectors, &wires, &claims);
        }
    }

    #[test]
    fn first_cubic_message_matches_direct_polynomial_values() {
        let mut rng = Rng::new(0xC0B1_Ca11);
        let (selectors, wires, basis_sum) = fixture(7, 7, &mut rng);
        let (proof, _) = prove(
            wires.each_ref().map(Vec::as_slice),
            &selectors,
            7,
            basis_sum,
            &mut challenger(),
        )
        .unwrap();
        let x = start(7, 7, basis_sum, &mut challenger());
        for t in [F128::ZERO, F128::ONE, rng.f128(), rng.f128()] {
            let mut expected = F128::ZERO;
            for i in 0..wires[0].len() / 2 {
                let q: [F128; 5] = std::array::from_fn(|j| {
                    let q0 = selector_bit(&selectors, j, 2 * i);
                    let q1 = selector_bit(&selectors, j, 2 * i + 1);
                    q0 + t * (q0 + q1)
                });
                let w: [F128; 4] = std::array::from_fn(|j| {
                    wires[j][2 * i] + t * (wires[j][2 * i] + wires[j][2 * i + 1])
                });
                expected +=
                    eq_index(&x[1..], i) * (F128::ONE + x[0] + t) * residual(&q, &w, basis_sum);
            }
            assert_eq!(evaluate(proof.rounds[0], F128::ZERO, t), expected);
        }
    }

    #[test]
    fn round_kernel_matches_scalar_for_general_folded_selectors_and_tails() {
        let mut rng = Rng::new(0xB10C_9E70);
        for log_n in [1usize, 2, 3, 7, 10, 15] {
            let n = 1usize << log_n;
            let wires: [Vec<F128>; 4] = std::array::from_fn(|_| rng.f128_vec(n));
            let period = 1usize << log_n.min(7);
            let mut selectors: [Vec<F128>; 5] = std::array::from_fn(|_| rng.f128_vec(period));
            selectors[0].fill(F128::ZERO);
            selectors[1].fill(F128::ONE);
            let point = rng.f128_vec(log_n - 1);
            let basis_sum = rng.f128();
            let mut expected = [F128::ZERO; 3];
            for i in 0..n / 2 {
                let q0: [F128; 5] = std::array::from_fn(|j| selectors[j][(2 * i) & (period - 1)]);
                let q1: [F128; 5] =
                    std::array::from_fn(|j| selectors[j][(2 * i + 1) & (period - 1)]);
                let w0 = std::array::from_fn(|j| wires[j][2 * i]);
                let w1 = std::array::from_fn(|j| wires[j][2 * i + 1]);
                let weight = eq_index(&point, i);
                expected[0] += weight * residual(&q0, &w0, basis_sum);
                expected[1] += weight * residual(&q1, &w1, basis_sum);
                expected[2] +=
                    weight * (0..4).fold(F128::ZERO, |v, j| v + (q0[j] + q1[j]) * (w0[j] + w1[j]));
            }
            let actual = round_message(
                wires.each_ref().map(Vec::as_slice),
                &point,
                &selectors,
                basis_sum,
            );
            assert_eq!(actual, expected, "log_n={log_n}");
        }
    }

    #[test]
    fn bad_gate_messages_and_terminal_values_are_rejected() {
        let mut rng = Rng::new(0xBAD_9A7E);
        let (mut selectors, mut wires, basis_sum) = fixture(8, 1, &mut rng);
        selectors.packed = [vec![2], vec![2], vec![1], vec![3], vec![0]];
        for i in 0..wires[0].len() {
            wires[3][i] = if i & 1 == 0 {
                wires[2][i]
            } else {
                wires[0][i] + wires[1][i]
            };
        }
        let (proof, claims) = prove(
            wires.each_ref().map(Vec::as_slice),
            &selectors,
            8,
            basis_sum,
            &mut challenger(),
        )
        .unwrap();
        for kind in 0..13 {
            let mut bad = proof.clone();
            match kind {
                0..=2 => bad.rounds[0][kind] += F128::ONE,
                3..=7 => bad.selectors[kind - 3] += F128::ONE,
                8..=11 => bad.wires[kind - 8] += F128::ONE,
                12 => {
                    bad.rounds.pop();
                }
                _ => unreachable!(),
            }
            assert!(
                verify(&bad, 8, 1, basis_sum, &mut challenger()).is_err(),
                "kind={kind}"
            );
        }
        assert!(verify(&proof, 8, 2, basis_sum, &mut challenger()).is_err());
        assert!(verify(&proof, 8, 1, basis_sum + F128::ONE, &mut challenger()).is_err());
        wires[3][0] += F128::ONE;
        assert!(
            prove(
                wires.each_ref().map(Vec::as_slice),
                &selectors,
                8,
                basis_sum,
                &mut challenger()
            )
            .is_err()
        );
        assert_ne!(source_value(&wires[3], &claims.point), claims.wires[3]);
    }

    #[test]
    fn dimensions_period_padding_and_native_fold_are_checked() {
        assert!(checked_len(0, 1).is_err());
        assert!(checked_len(10, 8).is_err());
        assert!(checked_len(usize::BITS as usize, 0).is_err());
        #[cfg(target_pointer_width = "64")]
        assert_eq!(checked_len(30, 7).unwrap(), 1usize << 30);
        let selectors = RepeatedSelectors {
            period_log: 1,
            packed: std::array::from_fn(|_| vec![4]),
        };
        assert!(selectors.initial_state(7).is_err());
        let mut rng = Rng::new(0xF01D_93);
        for n in [2, 4, 6, 2046, 2048, 2050, 32768, 32770] {
            let source = rng.f128_vec(n);
            for r in [F128::ZERO, F128::ONE, rng.f128()] {
                let mut output = vec![F128::ONE; n + 3];
                fold_into(&source, r, &mut output);
                let expected: Vec<_> = source
                    .chunks_exact(2)
                    .map(|p| p[0] + r * (p[0] + p[1]))
                    .collect();
                assert_eq!(output, expected);
            }
        }
    }
}
