use super::fixture::{basis, from_raw};
use flock_core::{
    pcs::{
        functional::{TensorClaim, row_weights},
        ring_switch::{claim_check, fold_1b_rows_naive, fold_1b_rows_split},
    },
    zerocheck::PaddingSpec,
};
use flock_field::F128;

pub fn pairs(point: &[F128]) -> Vec<[F128; 2]> {
    point.iter().map(|&r| [F128::ONE + r, r]).collect()
}
pub fn tensor(point: &[F128]) -> Vec<F128> {
    row_weights(&pairs(point))
}
pub fn matrix(q: mikros::MatrixClaim) -> TensorClaim {
    TensorClaim {
        columns: q.column_weights,
        rows: q.row_factors.into_iter().rev().collect(),
        value: q.value,
    }
}
pub fn ordinary(point: &[F128], value: F128) -> TensorClaim {
    TensorClaim {
        columns: basis(),
        rows: pairs(point),
        value,
    }
}
/// Restrict a block, retaining its external scale on the column functional.
pub fn lift(mut q: TensorClaim, block: usize, log_total_words: usize) -> TensorClaim {
    let old = q.rows.len();
    assert!(old <= log_total_words);
    assert!(block < 1usize << (log_total_words - old));
    q.rows.extend((0..log_total_words - old).map(|i| {
        if block & (1 << i) == 0 {
            [F128::ONE, F128::ZERO]
        } else {
            [F128::ZERO, F128::ONE]
        }
    }));
    q
}
pub fn scale(mut q: TensorClaim, a: F128) -> TensorClaim {
    for x in &mut q.columns {
        *x *= a;
    }
    q.value *= a;
    q
}
pub fn evaluate(words: &[F128], q: &TensorClaim) -> F128 {
    assert_eq!(words.len(), 1usize << q.rows.len());
    assert_eq!(q.columns.len(), 128);
    let folded = if q.rows.len() < 4 {
        fold_1b_rows_naive(words, &row_weights(&q.rows))
    } else {
        let split = q.rows.len().div_ceil(2).max(4).min(q.rows.len());
        fold_1b_rows_split(
            words,
            &row_weights(&q.rows[..split]),
            &row_weights(&q.rows[split..]),
            &PaddingSpec::dense(q.rows.len() + 7),
        )
    };
    claim_check(&q.columns, &folded)
}
pub fn eval_with_value(words: &[F128], mut q: TensorClaim) -> TensorClaim {
    q.value = evaluate(words, &q);
    q
}
pub fn selector_column(which: usize) -> Vec<F128> {
    (0..128)
        .map(|j| if j == which { F128::ONE } else { F128::ZERO })
        .collect()
}
pub fn label_columns(start: usize, h: usize) -> Vec<F128> {
    (0..128)
        .map(|j| {
            if (start..start + h).contains(&j) {
                from_raw(1u128 << (j - start))
            } else {
                F128::ZERO
            }
        })
        .collect()
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn lifting_keeps_block_and_scale() {
        let words = (0..1024)
            .map(|i| F128::new(i as u64, 0))
            .collect::<Vec<_>>();
        let q = ordinary(&[F128::new(3, 0); 7], F128::ZERO);
        let q = eval_with_value(&words[384..512], q);
        let scaled = scale(q, F128::new(17, 0));
        let lifted = lift(scaled, 3, 10);
        assert_eq!(evaluate(&words, &lifted), lifted.value);
    }
}
