# Exact-gate PLONK E2E experiment

Single: one connected circuit with `N` genuine AND/XOR gates. Multiple: 128
independent inputs to the same circuit shape, **each with N gates**, `128*N`
total. The execution thread count is separately fixed at 64.

These files prepare and execute an experiment; they contain no measured result.
Source freeze, upload and execution are separate actions controlled by root.

## Prepare

`package_sources.py OUTPUT --list-only` inventories sources without freezing.
After integration is ready, run without `--list-only`; `OUTPUT` must be inside
this experiment directory. It writes a source tarball, its SHA-256 and an exact
per-file hash manifest, including new m36–39 native Fast PCS configurations.
It excludes history, credentials, unrelated projects and build artifacts.

## Server

Extract under the authorized
`/home/mscong1/mikros-experiments/20260912T-native64/v15-plonk-e2e-20260914/source`.
Run from that snapshot:

```sh
python3 mikros/server_experiments/20260914-plonk-e2e/run_server.py --levels 14 --logs results-pilot14
```

`--dry-run` prints the plan without writing or executing. The default levels are
14, 20, 26, 30 in that order. Explicit `--levels 20`, `--levels 26`, or `--levels 30`
allows root to inspect earlier pilot evidence before progressing. Each selected
level runs four serial, separate processes with one repetition by default.

The build reuses the authorized v14 target cache, with native ISA flags and the
same nightly toolchain. No cargo clean or disk cleanup occurs. Only the authorized
`/home` tree is written; another user's `/data` directory is never used. The
driver checks available RAM, disk space, CPU idleness, selected hardware flags,
compiler flags, source hashes and binary hashes. It keeps subprocess output and
`/usr/bin/time -v` evidence even if a case panics or times out.

`--skip-build --reuse-evidence PATH` requires a same-source, same-binary build
receipt. `--skip-tests` is explicit and recorded; omitted tests are never reported
as passed. Result directories must be fresh and are not overwritten. Case timeouts
default to four hours; changing them does not create an unattended scheduler.

## Evidence and scope

`aggregate_results.py RESULTS` reconstructs a validated summary from actual raw
JSONL and statuses. It writes `summary.json`, `single_instance.log`,
`multiple_instance.log`, and hashes of evidence files. Root may place the two
instance logs at the repository root after retrieval. Missing or failed cases
stay explicitly incomplete and do not get ratios.

Comparisons require equal witness/public commitment hashes and equal witness/public
native FLOCK PCS parameters. Both online PCS openings, witness commitment and
recommit, public recommit, PIOPs, release and proof serialization are timed.
Initial public commitment and static input preparation are offline. Conversion
inside gate/copy PIOPs is included in those stage times; no separate conversion
timing is invented. One repetition describes a run and cannot establish statistical
significance. `/usr/bin/time` RSS covers the entire fresh process, including offline
setup and verification, not an isolated prover-only allocation peak.

At N30 the full multi-instance witness PCS buffer is 64 GiB, its rate-1/2 codeword
128 GiB, and its Merkle tree 8 GiB. Stage release/recommit is therefore necessary.
The default large-case RAM preflight requires 350 GiB available; this is a guard,
not a claim that the proof fits. Actual peak RSS and stage logs decide feasibility.
