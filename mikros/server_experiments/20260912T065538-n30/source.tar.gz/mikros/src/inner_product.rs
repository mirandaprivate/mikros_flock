//! Degree-two sumcheck for a length-2^ell inner product, low bit first.
//! Each round sends g(0) and the X^2 coefficient. In characteristic two,
//! g(0)+g(1)=claim implies g(t)=g(0)+t*claim+(t^2+t)*g_infinity.

use flock_field::{F128, F256Unreduced};
use flock_multilinear::fold_low;
use flock_transcript::challenger::Challenger;
use rayon::prelude::{IndexedParallelIterator, ParallelIterator, ParallelSlice, ParallelSliceMut};
use serde::{Deserialize, Serialize};

use crate::hadamard::Error;

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct InnerProductProof {
    pub rounds: Vec<[F128; 2]>,
    pub final_a: F128,
    pub final_b: F128,
}

fn round_message(a: &[F128], b: &[F128]) -> [F128; 2] {
    let sum_chunk = |(a, b): (&[F128], &[F128])| {
        let mut out = [F128::ZERO; 2];
        for (a, b) in a.chunks_exact(2).zip(b.chunks_exact(2)) {
            out[0] += a[0] * b[0];
            out[1] += (a[0] + a[1]) * (b[0] + b[1]);
        }
        out
    };
    if a.len() < 4096 {
        sum_chunk((a, b))
    } else {
        a.par_chunks(2048)
            .zip(b.par_chunks(2048))
            .map(sum_chunk)
            .reduce(|| [F128::ZERO; 2], |a, b| [a[0] + b[0], a[1] + b[1]])
    }
}

pub fn prove<C: Challenger>(
    mut a: Vec<F128>,
    mut b: Vec<F128>,
    challenger: &mut C,
) -> (InnerProductProof, Vec<F128>) {
    debug_assert_eq!(a.len(), b.len());
    debug_assert!(a.len().is_power_of_two());
    challenger.observe_label(b"mikros-inner-product-v1");
    let mut rounds = Vec::with_capacity(a.len().ilog2() as usize);
    let mut point = Vec::with_capacity(rounds.capacity());
    while a.len() > 1 {
        let message = round_message(&a, &b);
        challenger.observe_f128_slice(&message);
        let challenge = challenger.sample_f128();
        fold_low(&mut a, challenge);
        fold_low(&mut b, challenge);
        rounds.push(message);
        point.push(challenge);
    }
    challenger.observe_f128_slice(&[a[0], b[0]]);
    // Public matrix queries use HighToLow coordinates.
    point.reverse();
    (
        InnerProductProof {
            rounds,
            final_a: a[0],
            final_b: b[0],
        },
        point,
    )
}

// Chunk boundaries always preserve adjacent output pairs. A task writes two
// 64-KiB output chunks, and consumes four input values per message summand.
// Keep short tail rounds and a one-worker pool on the straight-line path:
// otherwise scheduling can dominate the handful of field operations per row.
const FOLD_OUTPUT_CHUNK: usize = 4096;
const PARALLEL_INPUT_THRESHOLD: usize = 32768;

fn use_parallel(input_len: usize) -> bool {
    input_len >= PARALLEL_INPUT_THRESHOLD && rayon::current_num_threads() > 1
}

fn add_unreduced(left: [F256Unreduced; 2], right: [F256Unreduced; 2]) -> [F256Unreduced; 2] {
    [left[0] ^ right[0], left[1] ^ right[1]]
}

/// Initial round message without reducing each separate product. Reduction
/// modulo the GHASH polynomial is XOR-linear, so the two total accumulators
/// give exactly the baseline's two sums.
fn round_message_packed(a: &[F128], b: &[F128]) -> [F128; 2] {
    let sum_chunk = |(a, b): (&[F128], &[F128])| {
        let mut out = [F256Unreduced::ZERO; 2];
        for (a, b) in a.chunks_exact(2).zip(b.chunks_exact(2)) {
            out[0] ^= a[0].mul_unreduced(b[0]);
            out[1] ^= (a[0] + a[1]).mul_unreduced(b[0] + b[1]);
        }
        out
    };
    let sums = if !use_parallel(a.len()) {
        sum_chunk((a, b))
    } else {
        a.par_chunks(2 * FOLD_OUTPUT_CHUNK)
            .zip(b.par_chunks(2 * FOLD_OUTPUT_CHUNK))
            .map(sum_chunk)
            .reduce(|| [F256Unreduced::ZERO; 2], add_unreduced)
    };
    sums.map(F256Unreduced::reduce)
}

/// Bind one challenge and accumulate the following round's message from the
/// freshly computed values. Each four inputs produce two outputs and one
/// quadratic-message summand. No transformed value is recomputed or reread
/// from a full intermediate vector to construct that message.
fn fold_chunk_and_message(
    a: &[F128],
    b: &[F128],
    a_out: &mut [F128],
    b_out: &mut [F128],
    challenge: F128,
) -> [F256Unreduced; 2] {
    debug_assert_eq!(a.len(), b.len());
    debug_assert_eq!(a.len(), 2 * a_out.len());
    debug_assert_eq!(a_out.len(), b_out.len());
    debug_assert_eq!(a.len() % 4, 0);
    let mut sums = [F256Unreduced::ZERO; 2];
    for (((a, b), a_out), b_out) in a
        .chunks_exact(4)
        .zip(b.chunks_exact(4))
        .zip(a_out.chunks_exact_mut(2))
        .zip(b_out.chunks_exact_mut(2))
    {
        // Same one-multiply interpolation used by the baseline's fold_low.
        let a0 = a[0] + challenge * (a[1] + a[0]);
        let a1 = a[2] + challenge * (a[3] + a[2]);
        let b0 = b[0] + challenge * (b[1] + b[0]);
        let b1 = b[2] + challenge * (b[3] + b[2]);
        a_out[0] = a0;
        a_out[1] = a1;
        b_out[0] = b0;
        b_out[1] = b1;
        sums[0] ^= a0.mul_unreduced(b0);
        sums[1] ^= (a0 + a1).mul_unreduced(b0 + b1);
    }
    sums
}

fn fold_and_message(
    a: &[F128],
    b: &[F128],
    a_out: &mut [F128],
    b_out: &mut [F128],
    challenge: F128,
) -> [F128; 2] {
    assert_eq!(a.len(), b.len());
    assert_eq!(a.len(), 2 * a_out.len());
    assert_eq!(a_out.len(), b_out.len());
    assert_eq!(a.len() % 4, 0);
    let sums = if !use_parallel(a.len()) {
        fold_chunk_and_message(a, b, a_out, b_out, challenge)
    } else {
        a_out
            .par_chunks_mut(FOLD_OUTPUT_CHUNK)
            .zip(b_out.par_chunks_mut(FOLD_OUTPUT_CHUNK))
            .enumerate()
            .map(|(chunk, (a_out, b_out))| {
                let start = 2 * chunk * FOLD_OUTPUT_CHUNK;
                let end = start + 2 * a_out.len();
                fold_chunk_and_message(&a[start..end], &b[start..end], a_out, b_out, challenge)
            })
            .reduce(|| [F256Unreduced::ZERO; 2], add_unreduced)
    };
    sums.map(F256Unreduced::reduce)
}

/// Transcript-identical engineering variant of [`prove`]. The first message
/// is computed directly; every subsequent message shares its input pass with
/// the preceding challenge's fold. Parallel workers own disjoint output
/// slices, and two half-size scratch buffers are reused across all rounds.
pub fn prove_packed<C: Challenger>(
    mut a: Vec<F128>,
    mut b: Vec<F128>,
    challenger: &mut C,
) -> (InnerProductProof, Vec<F128>) {
    assert_eq!(a.len(), b.len());
    assert!(a.len().is_power_of_two());
    challenger.observe_label(b"mikros-inner-product-v1");
    let mut rounds = Vec::with_capacity(a.len().ilog2() as usize);
    let mut point = Vec::with_capacity(rounds.capacity());
    if a.len() > 1 {
        let mut message = round_message_packed(&a, &b);
        // Safe initialized storage, allocated once. After each swap the old
        // input allocation becomes the destination for a strictly shorter
        // output, so every written slice stays within its initialized length.
        let scratch_len = if a.len() >= 4 { a.len() / 2 } else { 0 };
        let mut a_next = vec![F128::ZERO; scratch_len];
        let mut b_next = vec![F128::ZERO; scratch_len];
        loop {
            challenger.observe_f128_slice(&message);
            let challenge = challenger.sample_f128();
            rounds.push(message);
            point.push(challenge);
            if a.len() == 2 {
                a[0] = a[0] + challenge * (a[1] + a[0]);
                b[0] = b[0] + challenge * (b[1] + b[0]);
                break;
            }
            let half = a.len() / 2;
            message = fold_and_message(&a, &b, &mut a_next[..half], &mut b_next[..half], challenge);
            std::mem::swap(&mut a, &mut a_next);
            std::mem::swap(&mut b, &mut b_next);
            a.truncate(half);
            b.truncate(half);
        }
    }
    challenger.observe_f128_slice(&[a[0], b[0]]);
    point.reverse();
    (
        InnerProductProof {
            rounds,
            final_a: a[0],
            final_b: b[0],
        },
        point,
    )
}

pub fn verify<C: Challenger>(
    proof: &InnerProductProof,
    mut claim: F128,
    challenger: &mut C,
) -> Result<Vec<F128>, Error> {
    challenger.observe_label(b"mikros-inner-product-v1");
    let mut point = Vec::with_capacity(proof.rounds.len());
    for &[at_zero, at_infinity] in &proof.rounds {
        challenger.observe_f128_slice(&[at_zero, at_infinity]);
        let challenge = challenger.sample_f128();
        claim = at_zero + challenge * claim + (challenge.square() + challenge) * at_infinity;
        point.push(challenge);
    }
    challenger.observe_f128_slice(&[proof.final_a, proof.final_b]);
    if claim != proof.final_a * proof.final_b {
        return Err(Error::InnerProductMismatch);
    }
    point.reverse();
    Ok(point)
}

#[cfg(test)]
mod tests {
    use super::{fold_and_message, prove, prove_packed, round_message, verify};
    use flock_field::{F128, test_rng::Rng};
    use flock_multilinear::fold_low;
    use flock_transcript::challenger::{Challenger, FsChallenger};

    #[test]
    fn fused_fold_and_message_matches_direct_work_at_chunk_boundaries() {
        let pool = rayon::ThreadPoolBuilder::new()
            .num_threads(3)
            .build()
            .unwrap();
        pool.install(|| {
            let mut rng = Rng::new(0xF05E_1F01);
            // Non-power-of-two lengths exercise partial final chunks in this
            // private kernel; real protocol vectors are powers of two.
            for n in [4, 8, 8188, 8192, 8196, 32764, 32768, 32772, 65540] {
                let a = rng.f128_vec(n);
                let b = rng.f128_vec(n);
                for challenge in [F128::ZERO, F128::ONE, rng.f128()] {
                    let direct_fold = |input: &[F128]| -> Vec<F128> {
                        input
                            .chunks_exact(2)
                            .map(|pair| pair[0] * (F128::ONE + challenge) + pair[1] * challenge)
                            .collect()
                    };
                    let expected_a = direct_fold(&a);
                    let expected_b = direct_fold(&b);
                    let mut actual_a = vec![F128::ZERO; n / 2];
                    let mut actual_b = vec![F128::ZERO; n / 2];
                    let message = fold_and_message(&a, &b, &mut actual_a, &mut actual_b, challenge);
                    assert_eq!(actual_a, expected_a, "a, input length {n}");
                    assert_eq!(actual_b, expected_b, "b, input length {n}");
                    assert_eq!(
                        message,
                        round_message(&expected_a, &expected_b),
                        "message, input length {n}"
                    );
                }
            }
        });
    }

    #[test]
    fn packed_proof_and_transcript_match_baseline_across_lengths_and_threads() {
        for threads in [1, 2, 6] {
            let pool = rayon::ThreadPoolBuilder::new()
                .num_threads(threads)
                .build()
                .unwrap();
            pool.install(|| {
                let mut rng = Rng::new(0xF05E_1F02);
                for n in [1, 2, 4, 32, 1024, 4096, 16384, 32768, 65536] {
                    for pattern in 0..3 {
                        let mut a = rng.f128_vec(n);
                        let mut b = rng.f128_vec(n);
                        if pattern == 1 {
                            a.fill(F128::ZERO);
                        } else if pattern == 2 {
                            a.fill(F128::ONE);
                            b.fill(F128::ZERO);
                            b[n - 1] = F128::generator();
                        }
                        let claim = a
                            .iter()
                            .zip(&b)
                            .fold(F128::ZERO, |sum, (&a, &b)| sum + a * b);
                        let domain = b"mikros-packed-inner-product-differential-v1";
                        let mut baseline_ch = FsChallenger::new(domain);
                        let baseline = prove(a.clone(), b.clone(), &mut baseline_ch);
                        let mut packed_ch = FsChallenger::new(domain);
                        let packed = prove_packed(a.clone(), b.clone(), &mut packed_ch);
                        assert_eq!(
                            packed, baseline,
                            "threads {threads}, length {n}, pattern {pattern}"
                        );
                        assert_eq!(packed_ch.sample_f128(), baseline_ch.sample_f128());
                        let point =
                            verify(&packed.0, claim, &mut FsChallenger::new(domain)).unwrap();
                        assert_eq!(point, packed.1);

                        // Independently fold the original vectors using the
                        // returned HighToLow coordinates, including zero rounds.
                        for &coordinate in point.iter().rev() {
                            fold_low(&mut a, coordinate);
                            fold_low(&mut b, coordinate);
                        }
                        assert_eq!(a[0], packed.0.final_a);
                        assert_eq!(b[0], packed.0.final_b);
                    }
                }
            });
        }
    }
}
