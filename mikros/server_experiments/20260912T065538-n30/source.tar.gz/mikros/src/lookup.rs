//! Binary chunk tables for tensor transforms and challenge-point binding.

use flock_field::{F128, F256Unreduced};
use rayon::prelude::{
    IndexedParallelIterator, IntoParallelIterator, ParallelIterator, ParallelSlice,
};

use crate::tensor::{KAPPA, Kernel};

const ROW_BYTES: usize = KAPPA / 8;

/// `T^{tensor 3}` maps eight input bits to 27 coefficient bits. This table
/// is witness- and challenge-independent, and occupies exactly one KiB.
pub(crate) static BYTE_TRANSFORM: [u32; 256] = make_byte_transform();

const fn make_byte_transform() -> [u32; 256] {
    let mut columns = [0u32; 8];
    let mut column = 0;
    while column < 8 {
        let mut coefficient = 0;
        while coefficient < 27 {
            let mut ternary = coefficient;
            let mut binary = column;
            let mut matches = true;
            let mut axis = 0;
            while axis < 3 {
                let digit = ternary % 3;
                if digit != 2 && digit != binary % 2 {
                    matches = false;
                }
                ternary /= 3;
                binary /= 2;
                axis += 1;
            }
            if matches {
                columns[column] |= 1 << coefficient;
            }
            coefficient += 1;
        }
        column += 1;
    }
    let mut table = [0u32; 256];
    let mut byte = 1usize;
    while byte < 256 {
        let bit = byte.trailing_zeros() as usize;
        table[byte] = table[byte & (byte - 1)] ^ columns[bit];
        byte += 1;
    }
    table
}

/// Bind each bit-packed 128-bit row to the supplied 128 column weights.
///
/// Lookup mode builds sixteen byte subset-XOR tables (64 KiB) for these
/// weights once per call, then performs sixteen lookups per row. Unlike the
/// fixed tensor table, these tables depend on the challenge; their creation
/// belongs in online packing time. There is no heap allocation per row.
pub fn pack_rows(packed: &[u8], weights: &[F128], kernel: Kernel) -> Vec<F128> {
    assert_eq!(weights.len(), KAPPA, "packing requires 128 column weights");
    assert_eq!(
        packed.len() % ROW_BYTES,
        0,
        "input must contain complete rows"
    );
    match kernel {
        Kernel::Reference => packed
            .chunks_exact(ROW_BYTES)
            .map(|row| {
                weights
                    .iter()
                    .enumerate()
                    .fold(F128::ZERO, |sum, (column, &weight)| {
                        if row[column / 8] >> (column % 8) & 1 != 0 {
                            sum + weight
                        } else {
                            sum
                        }
                    })
            })
            .collect(),
        Kernel::Lookup | Kernel::Packed | Kernel::Packed8 => {
            let mut tables = vec![[F128::ZERO; 256]; ROW_BYTES];
            for (byte, table) in tables.iter_mut().enumerate() {
                for value in 1usize..256 {
                    let bit = value.trailing_zeros() as usize;
                    table[value] = table[value ^ (1 << bit)] + weights[byte * 8 + bit];
                }
            }
            packed
                .par_chunks_exact(ROW_BYTES)
                .with_min_len(256)
                .map(|row| {
                    row.iter()
                        .zip(&tables)
                        .fold(F128::ZERO, |sum, (&byte, table)| sum + table[byte as usize])
                })
                .collect()
        }
    }
}

/// A challenge-dependent table shared by A and B. Its construction stays in
/// online proving time; unlike BYTE_TRANSFORM it cannot be cached globally.
struct BindingTable {
    data: Vec<[F128; 256]>,
}

impl BindingTable {
    fn new(weights: &[F128]) -> Self {
        assert_eq!(weights.len(), KAPPA);
        let mut data = vec![[F128::ZERO; 256]; ROW_BYTES];
        for (byte, table) in data.iter_mut().enumerate() {
            for bit in 0..8 {
                let half = 1 << bit;
                for mask in 0..half {
                    table[half + mask] = table[mask] + weights[byte * 8 + bit];
                }
            }
        }
        Self { data }
    }

    #[inline]
    fn fold(&self, row: &[u8]) -> F128 {
        let mut sums = [F128::ZERO; 4];
        for (bytes, tables) in row.chunks_exact(4).zip(self.data.chunks_exact(4)) {
            sums[0] += tables[0][bytes[0] as usize];
            sums[1] += tables[1][bytes[1] as usize];
            sums[2] += tables[2][bytes[2] as usize];
            sums[3] += tables[3][bytes[3] as usize];
        }
        sums[0] + sums[1] + sums[2] + sums[3]
    }
}

/// Pack A/B together with one rho table and apply B's row weights on write.
pub(crate) fn pack_pair_weighted(
    a: &[u8],
    b: &[u8],
    column_weights: &[F128],
    row_weights: &[F128],
) -> (Vec<F128>, Vec<F128>) {
    assert_eq!(a.len(), b.len());
    assert_eq!(a.len(), row_weights.len() * ROW_BYTES);
    let table = BindingTable::new(column_weights);
    let bind = |row: usize| {
        let offset = row * ROW_BYTES;
        (
            table.fold(&a[offset..offset + ROW_BYTES]),
            table.fold(&b[offset..offset + ROW_BYTES]) * row_weights[row],
        )
    };
    if row_weights.len() < 4096 || rayon::current_num_threads() == 1 {
        (0..row_weights.len()).map(bind).unzip()
    } else {
        (0..row_weights.len())
            .into_par_iter()
            .with_min_len(1024)
            .map(bind)
            .unzip()
    }
}

/// Fuse C packing with its projection; do not materialize a packed C vector.
/// Reuse Flock's unreduced field product accumulator, reducing once per chunk.
pub(crate) fn project_rows(c: &[u8], column_weights: &[F128], row_weights: &[F128]) -> F128 {
    assert_eq!(c.len(), row_weights.len() * ROW_BYTES);
    let table = BindingTable::new(column_weights);
    let project = |(bytes, weights): (&[u8], &[F128])| {
        let mut sum = F256Unreduced::ZERO;
        for (row, &weight) in bytes.chunks_exact(ROW_BYTES).zip(weights) {
            sum ^= table.fold(row).mul_unreduced(weight);
        }
        sum.reduce()
    };
    if row_weights.len() < 4096 || rayon::current_num_threads() == 1 {
        project((c, row_weights))
    } else {
        c.par_chunks(1024 * ROW_BYTES)
            .zip(row_weights.par_chunks(1024))
            .map(project)
            .reduce(|| F128::ZERO, |a, b| a + b)
    }
}

#[cfg(test)]
mod tests {
    use super::{ROW_BYTES, pack_pair_weighted, pack_rows, project_rows};
    use crate::tensor::{KAPPA, Kernel};
    use flock_field::{F128, test_rng::Rng};

    #[test]
    fn all_byte_subsets_at_every_position_match_direct_sum() {
        let mut rng = Rng::new(0xB17B1AD);
        let weights = rng.f128_vec(KAPPA);
        let mut packed = vec![0u8; ROW_BYTES * ROW_BYTES * 256];
        for position in 0..ROW_BYTES {
            for byte in 0..256 {
                packed[(position * 256 + byte) * ROW_BYTES + position] = byte as u8;
            }
        }
        assert_eq!(
            pack_rows(&packed, &weights, Kernel::Lookup),
            pack_rows(&packed, &weights, Kernel::Reference)
        );
    }

    #[test]
    fn packing_random_rows_and_coordinate_basis_agrees() {
        let mut rng = Rng::new(0xC010AB4515);
        let mut packed = vec![0u8; 517 * ROW_BYTES];
        rng.fill_bytes(&mut packed);
        let weights = rng.f128_vec(KAPPA);
        assert_eq!(
            pack_rows(&packed, &weights, Kernel::Lookup),
            pack_rows(&packed, &weights, Kernel::Reference)
        );
        let basis: Vec<F128> = (0..KAPPA)
            .map(|column| {
                if column < 64 {
                    F128::new(1 << column, 0)
                } else {
                    F128::new(0, 1 << (column - 64))
                }
            })
            .collect();
        let expected: Vec<F128> = packed
            .chunks_exact(ROW_BYTES)
            .map(|row| {
                F128::new(
                    u64::from_le_bytes(row[..8].try_into().unwrap()),
                    u64::from_le_bytes(row[8..].try_into().unwrap()),
                )
            })
            .collect();
        assert_eq!(pack_rows(&packed, &basis, Kernel::Lookup), expected);
        assert!(pack_rows(&[], &weights, Kernel::Lookup).is_empty());
    }

    #[test]
    fn fused_binding_and_projection_match_independent_bit_sums() {
        let mut rng = Rng::new(0xF05ED);
        for rows in [0, 1, 7, 8, 9, 257, 4095, 4096, 4097] {
            let mut a = vec![0; rows * ROW_BYTES];
            let mut b = a.clone();
            rng.fill_bytes(&mut a);
            rng.fill_bytes(&mut b);
            let columns = rng.f128_vec(KAPPA);
            let mut weights = rng.f128_vec(rows);
            for weight in weights.iter_mut().step_by(7) {
                *weight = F128::ZERO;
            }
            let expected_a = pack_rows(&a, &columns, Kernel::Reference);
            let expected_b: Vec<_> = pack_rows(&b, &columns, Kernel::Reference)
                .into_iter()
                .zip(&weights)
                .map(|(value, &weight)| value * weight)
                .collect();
            let expected_projection = expected_b
                .iter()
                .fold(F128::ZERO, |sum, &value| sum + value);
            for threads in [1, 3] {
                rayon::ThreadPoolBuilder::new()
                    .num_threads(threads)
                    .build()
                    .unwrap()
                    .install(|| {
                        assert_eq!(
                            pack_pair_weighted(&a, &b, &columns, &weights),
                            (expected_a.clone(), expected_b.clone())
                        );
                        assert_eq!(project_rows(&b, &columns, &weights), expected_projection);
                    });
            }
        }
    }

    #[test]
    #[should_panic(expected = "complete rows")]
    fn packing_rejects_partial_rows() {
        pack_rows(&[0; ROW_BYTES - 1], &[F128::ZERO; KAPPA], Kernel::Lookup);
    }
}
