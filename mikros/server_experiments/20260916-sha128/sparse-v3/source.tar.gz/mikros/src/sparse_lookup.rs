//! Binary sparse-matrix evaluation with indexed offline memory checking.
//!
//! This is the sparse-evaluation PIOP, not a polynomial commitment. Circuit
//! preprocessing fixes and authenticates every static column, including the
//! integer read/write/final timestamps and the binary value/padding column.
//! After x and y are known, the prover forms and commits the two gathered
//! equality tables BEFORE calling `prove`. The caller binds all commitments
//! and authenticates EVERY returned evaluation with its native PCS.
//!
//! Timestamps are u64 integers advanced during trusted preprocessing. Both
//! sides of each increment are committed independently; adding F128::ONE
//! would be an incorrect replacement for the integer increment. Verification
//! takes only the shape/digest, the query and the proof. It never scans the
//! matrix or a public equality table. It relies on the trusted preprocessing
//! statement for the address ranges, timestamp schedule and zero padding.
//!
//! A cubic sumcheck proves sum val[j]*read_row[j]*read_col[j]. Each gather is
//! checked by Init + Write = Read + Final using two complete product-tree
//! reductions. All points are LOW BIT FIRST. The two memory segments each
//! have D=max(table_len,read_len) slots; unused leaves are the public ONE.

use flock_core::r1cs::SparseBinaryMatrix;
use flock_field::F128;
use flock_transcript::challenger::Challenger;
use rayon::prelude::*;
use serde::{Deserialize, Serialize};

use crate::extension_product;

const MAX_LOG: usize = 30;

#[derive(Clone, Copy, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub enum OracleId {
    RowAddress,
    ColAddress,
    RowReadTime,
    RowWriteTime,
    ColReadTime,
    ColWriteTime,
    RowFinalTime,
    ColFinalTime,
    Value,
    ReadRow,
    ReadCol,
}

impl OracleId {
    pub const STATIC: [Self; 9] = [
        Self::RowAddress,
        Self::ColAddress,
        Self::RowReadTime,
        Self::RowWriteTime,
        Self::ColReadTime,
        Self::ColWriteTime,
        Self::RowFinalTime,
        Self::ColFinalTime,
        Self::Value,
    ];
}

/// Small verifier statement. The digest identifies the caller's trusted
/// preprocessed matrix commitment, including all nine static columns.
#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Statement {
    pub row_log: usize,
    pub col_log: usize,
    pub entry_log: usize,
    pub nonzeros: usize,
    pub digest: [u8; 32],
}

impl Statement {
    pub fn validate(&self) -> Result<(), Error> {
        for log in [self.row_log, self.col_log, self.entry_log] {
            checked_len(log)?;
        }
        if self.nonzeros > 1usize << self.entry_log
            || self.nonzeros.max(1).next_power_of_two() != 1usize << self.entry_log
        {
            return Err(Error::Shape);
        }
        Ok(())
    }

    pub fn column_log(&self, source: OracleId) -> usize {
        match source {
            OracleId::RowFinalTime => self.row_log,
            OracleId::ColFinalTime => self.col_log,
            _ => self.entry_log,
        }
    }

    /// Raw polynomial-basis bits needed by the native packed source carrier.
    pub fn column_bits(&self, source: OracleId) -> usize {
        match source {
            OracleId::RowAddress => self.row_log.max(1),
            OracleId::ColAddress => self.col_log.max(1),
            OracleId::Value => 1,
            OracleId::ReadRow | OracleId::ReadCol => 128,
            _ => self.entry_log + 1,
        }
    }
}

/// Offline prover data. A static column is never materialized as F128 here.
/// The caller may release this after its final online proof if desired.
#[derive(Clone, Debug)]
pub struct Prepared {
    pub row_log: usize,
    pub col_log: usize,
    pub entry_log: usize,
    pub nonzeros: usize,
    pub row: Vec<u64>,
    pub col: Vec<u64>,
    pub row_read_time: Vec<u64>,
    pub row_write_time: Vec<u64>,
    pub col_read_time: Vec<u64>,
    pub col_write_time: Vec<u64>,
    pub row_final_time: Vec<u64>,
    pub col_final_time: Vec<u64>,
    pub value: Vec<u64>,
}

impl Prepared {
    /// Canonicalize each binary matrix row by XORing its column postings.
    /// Repeated even-multiplicity entries are zero in GF(2), and never enter
    /// the committed COO or its timestamp log. A Rayon worker reuses its
    /// bitset across rows; the original circuit matrix remains unchanged.
    pub fn new(matrix: &SparseBinaryMatrix) -> Result<Self, Error> {
        if !matrix.num_rows.is_power_of_two()
            || !matrix.num_cols.is_power_of_two()
            || matrix.rows.len() != matrix.num_rows
        {
            return Err(Error::Shape);
        }
        let row_log = matrix.num_rows.ilog2() as usize;
        let col_log = matrix.num_cols.ilog2() as usize;
        checked_len(row_log)?;
        checked_len(col_log)?;
        let canonical: Vec<Vec<u64>> = matrix
            .rows
            .par_iter()
            .map_init(
                || vec![0u64; matrix.num_cols.div_ceil(64)],
                |bits, postings| {
                    bits.fill(0);
                    for &col in postings {
                        if col >= matrix.num_cols {
                            return Err(Error::Address);
                        }
                        bits[col / 64] ^= 1u64 << (col % 64);
                    }
                    let count = bits.iter().map(|word| word.count_ones() as usize).sum();
                    let mut columns = Vec::with_capacity(count);
                    for (block, &word) in bits.iter().enumerate() {
                        let mut remaining = word;
                        while remaining != 0 {
                            let bit = remaining.trailing_zeros() as usize;
                            columns.push((block * 64 + bit) as u64);
                            remaining &= remaining - 1;
                        }
                    }
                    Ok(columns)
                },
            )
            .collect::<Result<_, Error>>()?;
        let nonzeros = canonical.iter().try_fold(0usize, |n, row| {
            n.checked_add(row.len()).ok_or(Error::Shape)
        })?;
        if nonzeros > 1usize << MAX_LOG {
            return Err(Error::Shape);
        }
        let entries = nonzeros.max(1).next_power_of_two();
        let mut row = Vec::with_capacity(entries);
        let mut col = Vec::with_capacity(entries);
        for (i, columns) in canonical.into_iter().enumerate() {
            for j in columns {
                row.push(i as u64);
                col.push(j);
            }
        }
        row.resize(entries, 0);
        col.resize(entries, 0);
        let mut value = vec![0; entries];
        value[..nonzeros].fill(1);
        // Padding is a real read of address zero with value coefficient zero.
        // Its timestamps participate in exactly the same fixed memory log.
        let (row_read_time, row_write_time, row_final_time) = timestamps(&row, matrix.num_rows)?;
        let (col_read_time, col_write_time, col_final_time) = timestamps(&col, matrix.num_cols)?;
        Ok(Self {
            row_log,
            col_log,
            entry_log: entries.ilog2() as usize,
            nonzeros,
            row,
            col,
            row_read_time,
            row_write_time,
            col_read_time,
            col_write_time,
            row_final_time,
            col_final_time,
            value,
        })
    }

    pub fn statement(&self, digest: [u8; 32]) -> Statement {
        Statement {
            row_log: self.row_log,
            col_log: self.col_log,
            entry_log: self.entry_log,
            nonzeros: self.nonzeros,
            digest,
        }
    }

    pub fn static_column(&self, source: OracleId) -> Option<&[u64]> {
        Some(match source {
            OracleId::RowAddress => &self.row,
            OracleId::ColAddress => &self.col,
            OracleId::RowReadTime => &self.row_read_time,
            OracleId::RowWriteTime => &self.row_write_time,
            OracleId::ColReadTime => &self.col_read_time,
            OracleId::ColWriteTime => &self.col_write_time,
            OracleId::RowFinalTime => &self.row_final_time,
            OracleId::ColFinalTime => &self.col_final_time,
            OracleId::Value => &self.value,
            OracleId::ReadRow | OracleId::ReadCol => return None,
        })
    }

    /// Challenge-dependent online work. Bind commitments to BOTH returned
    /// vectors before calling `prove`, including any shared batch carrier.
    pub fn gather(&self, x: &[F128], y: &[F128]) -> Result<ReadData, Error> {
        checked_len(self.row_log)?;
        checked_len(self.col_log)?;
        if x.len() != self.row_log || y.len() != self.col_log {
            return Err(Error::Shape);
        }
        let rows = eq_table(x);
        let cols = eq_table(y);
        if self.row.iter().any(|&i| i as usize >= rows.len())
            || self.col.iter().any(|&i| i as usize >= cols.len())
        {
            return Err(Error::Address);
        }
        Ok(ReadData {
            read_row: self.row.par_iter().map(|&i| rows[i as usize]).collect(),
            read_col: self.col.par_iter().map(|&i| cols[i as usize]).collect(),
        })
    }
}

fn timestamps(addresses: &[u64], len: usize) -> Result<(Vec<u64>, Vec<u64>, Vec<u64>), Error> {
    let mut final_time = vec![0u64; len];
    let mut read = Vec::with_capacity(addresses.len());
    let mut write = Vec::with_capacity(addresses.len());
    for &address in addresses {
        let counter = final_time.get_mut(address as usize).ok_or(Error::Address)?;
        read.push(*counter);
        *counter = counter.checked_add(1).ok_or(Error::Shape)?;
        write.push(*counter);
    }
    Ok((read, write, final_time))
}

#[derive(Clone, Debug)]
pub struct ReadData {
    pub read_row: Vec<F128>,
    pub read_col: Vec<F128>,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Evaluation {
    pub source: OracleId,
    pub point: Vec<F128>,
    pub value: F128,
}

pub type Claim = Evaluation;

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct SumcheckProof {
    /// [g(0), coefficient of X^2, coefficient of X^3].
    pub rounds: Vec<[F128; 3]>,
    /// Value, ReadRow, ReadCol at the final common point.
    pub terminal: [F128; 3],
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct MemoryProof {
    pub product: extension_product::Proof,
    /// Left write: address/value/write-time; right read: address/value/read-
    /// time; right final: final-time. All seven values must be PCS-verified.
    pub evaluations: [F128; 7],
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Proof {
    pub matrix: SumcheckProof,
    pub row: MemoryProof,
    pub col: MemoryProof,
}

impl Proof {
    pub fn field_elements(&self) -> usize {
        3 * self.matrix.rounds.len()
            + 3
            + 14
            + self.row.product.field_elements()
            + self.col.product.field_elements()
    }
}

#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Error {
    Shape,
    Address,
    Sumcheck,
    Memory,
    Source,
    Product(extension_product::Error),
}

impl std::fmt::Display for Error {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "sparse matrix lookup: {self:?}")
    }
}
impl std::error::Error for Error {}
impl From<extension_product::Error> for Error {
    fn from(value: extension_product::Error) -> Self {
        Self::Product(value)
    }
}

fn checked_len(log: usize) -> Result<usize, Error> {
    if log > MAX_LOG || log + 1 >= usize::BITS as usize {
        return Err(Error::Shape);
    }
    Ok(1usize << log)
}

fn raw(value: u64) -> F128 {
    F128::new(value, 0)
}

fn eq_table(point: &[F128]) -> Vec<F128> {
    let mut table = vec![F128::ONE];
    for &r in point.iter().rev() {
        table = table
            .into_iter()
            .flat_map(|w| [w * (F128::ONE + r), w * r])
            .collect();
    }
    table
}

fn eval(values: &[F128], point: &[F128]) -> F128 {
    values
        .par_iter()
        .zip(eq_table(point).into_par_iter())
        .map(|(&value, weight)| value * weight)
        .reduce(|| F128::ZERO, |a, b| a + b)
}

fn eval_raw(values: &[u64], point: &[F128]) -> F128 {
    values
        .par_iter()
        .zip(eq_table(point).into_par_iter())
        .map(|(&value, weight)| raw(value) * weight)
        .reduce(|| F128::ZERO, |a, b| a + b)
}

fn bind<C: Challenger>(
    statement: &Statement,
    x: &[F128],
    y: &[F128],
    value: F128,
    ch: &mut C,
) -> Result<(), Error> {
    statement.validate()?;
    if x.len() != statement.row_log || y.len() != statement.col_log {
        return Err(Error::Shape);
    }
    ch.observe_label(b"mikros-binary-sparse-lookup-v1");
    for n in [
        statement.row_log,
        statement.col_log,
        statement.entry_log,
        statement.nonzeros,
    ] {
        ch.observe_bytes(&(n as u64).to_le_bytes());
    }
    ch.observe_bytes(&statement.digest);
    ch.observe_f128_slice(x);
    ch.observe_f128_slice(y);
    ch.observe_f128(value);
    Ok(())
}

fn message(a: &[F128], b: &[F128], c: &[F128]) -> [F128; 3] {
    a.par_chunks_exact(2)
        .zip(b.par_chunks_exact(2))
        .zip(c.par_chunks_exact(2))
        .map(|((a, b), c)| {
            let da = a[0] + a[1];
            let db = b[0] + b[1];
            let dc = c[0] + c[1];
            [
                a[0] * b[0] * c[0],
                da * db * c[0] + da * b[0] * dc + a[0] * db * dc,
                da * db * dc,
            ]
        })
        .reduce(
            || [F128::ZERO; 3],
            |a, b| std::array::from_fn(|i| a[i] + b[i]),
        )
}

fn evaluate_message(g: [F128; 3], claim: F128, r: F128) -> F128 {
    g[0] + r * (claim + g[1] + g[2] + r * (g[1] + r * g[2]))
}

fn fold(values: &[F128], r: F128) -> Vec<F128> {
    values
        .par_chunks_exact(2)
        .map(|v| v[0] + r * (v[0] + v[1]))
        .collect()
}

fn matrix_claims(point: &[F128], terminal: [F128; 3]) -> Vec<Evaluation> {
    [OracleId::Value, OracleId::ReadRow, OracleId::ReadCol]
        .into_iter()
        .zip(terminal)
        .map(|(source, value)| Evaluation {
            source,
            point: point.to_vec(),
            value,
        })
        .collect()
}

fn prove_matrix<C: Challenger>(
    prepared: &Prepared,
    reads: &ReadData,
    mut claim: F128,
    ch: &mut C,
) -> Result<(SumcheckProof, Vec<Evaluation>), Error> {
    ch.observe_label(b"mikros-sparse-matrix-cubic-v1");
    let mut a: Vec<_> = prepared.value.iter().map(|&v| raw(v)).collect();
    let mut b = reads.read_row.clone();
    let mut c = reads.read_col.clone();
    let initial = a
        .par_iter()
        .zip(&b)
        .zip(&c)
        .map(|((&a, &b), &c)| a * b * c)
        .reduce(|| F128::ZERO, |a, b| a + b);
    if initial != claim {
        return Err(Error::Sumcheck);
    }
    let mut rounds = Vec::with_capacity(prepared.entry_log);
    let mut point = Vec::with_capacity(prepared.entry_log);
    while a.len() > 1 {
        let g = message(&a, &b, &c);
        ch.observe_f128_slice(&g);
        let r = ch.sample_f128();
        claim = evaluate_message(g, claim, r);
        rounds.push(g);
        point.push(r);
        a = fold(&a, r);
        b = fold(&b, r);
        c = fold(&c, r);
    }
    let terminal = [a[0], b[0], c[0]];
    if terminal[0] * terminal[1] * terminal[2] != claim {
        return Err(Error::Sumcheck);
    }
    ch.observe_f128_slice(&terminal);
    Ok((
        SumcheckProof { rounds, terminal },
        matrix_claims(&point, terminal),
    ))
}

fn verify_matrix<C: Challenger>(
    statement: &Statement,
    proof: &SumcheckProof,
    mut claim: F128,
    ch: &mut C,
) -> Result<Vec<Evaluation>, Error> {
    if proof.rounds.len() != statement.entry_log {
        return Err(Error::Shape);
    }
    ch.observe_label(b"mikros-sparse-matrix-cubic-v1");
    let mut point = Vec::with_capacity(statement.entry_log);
    for &g in &proof.rounds {
        ch.observe_f128_slice(&g);
        let r = ch.sample_f128();
        point.push(r);
        claim = evaluate_message(g, claim, r);
    }
    if proof.terminal[0] * proof.terminal[1] * proof.terminal[2] != claim {
        return Err(Error::Sumcheck);
    }
    ch.observe_f128_slice(&proof.terminal);
    Ok(matrix_claims(&point, proof.terminal))
}

#[derive(Clone, Copy)]
enum Axis {
    Row,
    Col,
}

impl Axis {
    fn sources(self) -> [OracleId; 4] {
        match self {
            Self::Row => [
                OracleId::RowAddress,
                OracleId::ReadRow,
                OracleId::RowReadTime,
                OracleId::RowWriteTime,
            ],
            Self::Col => [
                OracleId::ColAddress,
                OracleId::ReadCol,
                OracleId::ColReadTime,
                OracleId::ColWriteTime,
            ],
        }
    }
    fn final_source(self) -> OracleId {
        match self {
            Self::Row => OracleId::RowFinalTime,
            Self::Col => OracleId::ColFinalTime,
        }
    }
    fn table_log(self, s: &Statement) -> usize {
        match self {
            Self::Row => s.row_log,
            Self::Col => s.col_log,
        }
    }
    fn values<'a>(self, data: &'a ReadData) -> &'a [F128] {
        match self {
            Self::Row => &data.read_row,
            Self::Col => &data.read_col,
        }
    }
}

#[derive(Clone, Copy)]
struct Fingerprint {
    shift: F128,
    address: F128,
    value: F128,
    time: F128,
}

impl Fingerprint {
    fn sample<C: Challenger>(axis: Axis, ch: &mut C) -> Self {
        ch.observe_label(b"mikros-sparse-indexed-memory-v1");
        ch.observe_bytes(&[match axis {
            Axis::Row => 0,
            Axis::Col => 1,
        }]);
        Self {
            shift: ch.sample_f128(),
            address: ch.sample_f128(),
            value: ch.sample_f128(),
            time: ch.sample_f128(),
        }
    }
    fn entry(self, address: u64, value: F128, time: u64) -> F128 {
        self.shift + self.address * raw(address) + self.value * value + self.time * raw(time)
    }
}

fn memory_queries(
    statement: &Statement,
    axis: Axis,
    leaves: &[extension_product::LeafClaim; 2],
    values: [F128; 7],
) -> Vec<Evaluation> {
    let [address, read, read_time, write_time] = axis.sources();
    let point_l = &leaves[0].point[..statement.entry_log];
    let point_r = &leaves[1].point[..statement.entry_log];
    let point_final = &leaves[1].point[..axis.table_log(statement)];
    [
        (address, point_l),
        (read, point_l),
        (write_time, point_l),
        (address, point_r),
        (read, point_r),
        (read_time, point_r),
        (axis.final_source(), point_final),
    ]
    .into_iter()
    .zip(values)
    .map(|((source, point), value)| Evaluation {
        source,
        point: point.to_vec(),
        value,
    })
    .collect()
}

fn prefix_factor(point: &[F128], log: usize) -> F128 {
    point[log..]
        .iter()
        .fold(F128::ONE, |v, &r| v * (F128::ONE + r))
}

fn identity_eval(point: &[F128]) -> F128 {
    point
        .iter()
        .enumerate()
        .fold(F128::ZERO, |v, (i, &r)| v + raw(1u64 << i) * r)
}

fn eq_eval(a: &[F128], b: &[F128]) -> F128 {
    a.iter()
        .zip(b)
        .fold(F128::ONE, |v, (&a, &b)| v * (F128::ONE + a + b))
}

fn check_memory(
    statement: &Statement,
    axis: Axis,
    table_point: &[F128],
    fingerprint: Fingerprint,
    leaves: &[extension_product::LeafClaim; 2],
    values: [F128; 7],
) -> Result<(), Error> {
    let table_log = axis.table_log(statement);
    let log_d = table_log.max(statement.entry_log);
    if leaves.iter().any(|leaf| leaf.point.len() != log_d + 1) {
        return Err(Error::Shape);
    }
    let f = fingerprint;
    for (side, leaf) in leaves.iter().enumerate() {
        let point = &leaf.point[..log_d];
        let selector = leaf.point[log_d];
        let table_active = prefix_factor(point, table_log);
        let read_active = prefix_factor(point, statement.entry_log);
        let table_base = f.shift
            + f.address * identity_eval(&point[..table_log])
            + f.value * eq_eval(table_point, &point[..table_log]);
        let (first, second) = if side == 0 {
            let init = F128::ONE + table_active * (F128::ONE + table_base);
            let write = F128::ONE
                + read_active
                    * (F128::ONE
                        + f.shift
                        + f.address * values[0]
                        + f.value * values[1]
                        + f.time * values[2]);
            (init, write)
        } else {
            let read = F128::ONE
                + read_active
                    * (F128::ONE
                        + f.shift
                        + f.address * values[3]
                        + f.value * values[4]
                        + f.time * values[5]);
            let final_state =
                F128::ONE + table_active * (F128::ONE + table_base + f.time * values[6]);
            (read, final_state)
        };
        if first + selector * (first + second) != leaf.value {
            return Err(Error::Memory);
        }
    }
    Ok(())
}

fn bind_memory_values<C: Challenger>(values: &[F128; 7], ch: &mut C) {
    ch.observe_label(b"mikros-sparse-memory-source-evaluations-v1");
    ch.observe_f128_slice(values);
}

fn prove_memory<C: Challenger>(
    prepared: &Prepared,
    statement: &Statement,
    reads: &ReadData,
    axis: Axis,
    table_point: &[F128],
    ch: &mut C,
) -> Result<(MemoryProof, Vec<Evaluation>), Error> {
    let f = Fingerprint::sample(axis, ch);
    let [address, _, read_time, write_time] = axis.sources();
    let addresses = prepared.static_column(address).ok_or(Error::Source)?;
    let read_times = prepared.static_column(read_time).ok_or(Error::Source)?;
    let write_times = prepared.static_column(write_time).ok_or(Error::Source)?;
    let final_times = prepared
        .static_column(axis.final_source())
        .ok_or(Error::Source)?;
    let values = axis.values(reads);
    let table = eq_table(table_point);
    let log_d = axis.table_log(statement).max(statement.entry_log);
    let d = 1usize << log_d;
    let (product, leaves, _) = extension_product::prove_pair(
        log_d + 1,
        |side, i| {
            let half = i / d;
            let i = i % d;
            match (side, half) {
                (0, 0) if i < table.len() => f.entry(i as u64, table[i], 0),
                (0, 1) if i < values.len() => f.entry(addresses[i], values[i], write_times[i]),
                (1, 0) if i < values.len() => f.entry(addresses[i], values[i], read_times[i]),
                (1, 1) if i < table.len() => f.entry(i as u64, table[i], final_times[i]),
                _ => F128::ONE,
            }
        },
        ch,
    )?;
    let templates = memory_queries(statement, axis, &leaves, [F128::ZERO; 7]);
    let evaluations = std::array::from_fn(|i| {
        let q = &templates[i];
        if let Some(source) = prepared.static_column(q.source) {
            eval_raw(source, &q.point)
        } else {
            eval(values, &q.point)
        }
    });
    check_memory(statement, axis, table_point, f, &leaves, evaluations)?;
    bind_memory_values(&evaluations, ch);
    Ok((
        MemoryProof {
            product,
            evaluations,
        },
        memory_queries(statement, axis, &leaves, evaluations),
    ))
}

fn verify_memory<C: Challenger>(
    statement: &Statement,
    axis: Axis,
    table_point: &[F128],
    proof: &MemoryProof,
    ch: &mut C,
) -> Result<Vec<Evaluation>, Error> {
    let f = Fingerprint::sample(axis, ch);
    let log_d = axis.table_log(statement).max(statement.entry_log);
    let leaves = extension_product::verify_pair(log_d + 1, &proof.product, ch)?;
    check_memory(statement, axis, table_point, f, &leaves, proof.evaluations)?;
    bind_memory_values(&proof.evaluations, ch);
    Ok(memory_queries(statement, axis, &leaves, proof.evaluations))
}

/// PIOP only. All static sources and both online gathers must already be
/// committed and bound. Authentication of all 17 returned claims is required.
pub fn prove<C: Challenger>(
    prepared: &Prepared,
    statement: &Statement,
    x: &[F128],
    y: &[F128],
    matrix_value: F128,
    reads: &ReadData,
    ch: &mut C,
) -> Result<(Proof, Vec<Evaluation>), Error> {
    bind(statement, x, y, matrix_value, ch)?;
    if prepared.statement(statement.digest) != *statement
        || OracleId::STATIC.iter().any(|&source| {
            prepared
                .static_column(source)
                .is_none_or(|values| values.len() != 1usize << statement.column_log(source))
        })
        || reads.read_row.len() != 1usize << statement.entry_log
        || reads.read_col.len() != 1usize << statement.entry_log
    {
        return Err(Error::Shape);
    }
    let (matrix, mut claims) = prove_matrix(prepared, reads, matrix_value, ch)?;
    let (row, row_claims) = prove_memory(prepared, statement, reads, Axis::Row, x, ch)?;
    claims.extend(row_claims);
    let (col, col_claims) = prove_memory(prepared, statement, reads, Axis::Col, y, ch)?;
    claims.extend(col_claims);
    Ok((Proof { matrix, row, col }, claims))
}

/// Succinct PIOP verifier: no matrix, address arrays, counters, gathered values
/// or equality tables are inputs. Caller verifies the returned PCS claims.
pub fn verify<C: Challenger>(
    statement: &Statement,
    x: &[F128],
    y: &[F128],
    matrix_value: F128,
    proof: &Proof,
    ch: &mut C,
) -> Result<Vec<Evaluation>, Error> {
    bind(statement, x, y, matrix_value, ch)?;
    let mut claims = verify_matrix(statement, &proof.matrix, matrix_value, ch)?;
    claims.extend(verify_memory(statement, Axis::Row, x, &proof.row, ch)?);
    claims.extend(verify_memory(statement, Axis::Col, y, &proof.col, ch)?);
    Ok(claims)
}

/// Linear-time source oracle for tests. This is NOT a PCS verifier.
pub fn check_claims(
    prepared: &Prepared,
    reads: &ReadData,
    claims: &[Evaluation],
) -> Result<(), Error> {
    for claim in claims {
        let expected = checked_len(claim.point.len())?;
        let (len, actual) = if let Some(values) = prepared.static_column(claim.source) {
            if values.len() != expected {
                return Err(Error::Source);
            }
            (values.len(), eval_raw(values, &claim.point))
        } else {
            let values = match claim.source {
                OracleId::ReadRow => &reads.read_row,
                OracleId::ReadCol => &reads.read_col,
                _ => return Err(Error::Source),
            };
            if values.len() != expected {
                return Err(Error::Source);
            }
            (values.len(), eval(values, &claim.point))
        };
        if len != expected || actual != claim.value {
            return Err(Error::Source);
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use flock_transcript::challenger::FsChallenger;

    fn ch() -> FsChallenger {
        FsChallenger::new(b"sparse-lookup-test")
    }
    fn query(log: usize, seed: u64) -> Vec<F128> {
        (0..log)
            .map(|i| F128::new(seed + 13 * i as u64, seed + 29 * i as u64))
            .collect()
    }
    fn value(p: &Prepared, reads: &ReadData) -> F128 {
        p.value
            .iter()
            .zip(&reads.read_row)
            .zip(&reads.read_col)
            .fold(F128::ZERO, |v, ((&a, &b), &c)| v + raw(a) * b * c)
    }

    #[test]
    fn sparse_lookup_roundtrip_rectangles_repeated_addresses_and_padding() {
        for matrix in [
            SparseBinaryMatrix::new(4, 8, vec![vec![7, 1, 3], vec![1], vec![0, 7], vec![3]]),
            SparseBinaryMatrix::new(
                8,
                2,
                vec![
                    vec![1],
                    vec![],
                    vec![],
                    vec![],
                    vec![],
                    vec![],
                    vec![],
                    vec![],
                ],
            ),
            SparseBinaryMatrix::new(1, 1, vec![vec![0]]),
            SparseBinaryMatrix::new(2, 4, vec![vec![], vec![]]),
            SparseBinaryMatrix::new(2, 2, vec![vec![1, 1, 0], vec![0, 1, 0, 1]]),
        ] {
            let p = Prepared::new(&matrix).unwrap();
            let s = p.statement([7; 32]);
            let x = query(s.row_log, 5);
            let y = query(s.col_log, 91);
            let reads = p.gather(&x, &y).unwrap();
            let v = value(&p, &reads);
            let mut prover = ch();
            let (proof, claims) = prove(&p, &s, &x, &y, v, &reads, &mut prover).unwrap();
            let mut verifier = ch();
            let got = verify(&s, &x, &y, v, &proof, &mut verifier).unwrap();
            assert_eq!(claims.len(), 17);
            assert_eq!(got, claims);
            check_claims(&p, &reads, &got).unwrap();
            assert_eq!(prover.sample_f128(), verifier.sample_f128());
            let bytes = bincode::serialize(&proof).unwrap();
            let proof: Proof = bincode::deserialize(&bytes).unwrap();
            assert!(verify(&s, &x, &y, v, &proof, &mut ch()).is_ok());
            let count = p.row_final_time.iter().sum::<u64>();
            assert_eq!(count, 1u64 << s.entry_log);
            assert!(p.value[s.nonzeros..].iter().all(|&x| x == 0));
        }
    }

    #[test]
    fn sparse_lookup_rejects_source_changes_wrong_reads_and_forged_messages() {
        let matrix =
            SparseBinaryMatrix::new(4, 4, vec![vec![3, 1, 2], vec![3], vec![0], vec![2, 1]]);
        let p = Prepared::new(&matrix).unwrap();
        let s = p.statement([9; 32]);
        let x = query(s.row_log, 13);
        let y = query(s.col_log, 111);
        let reads = p.gather(&x, &y).unwrap();
        let v = value(&p, &reads);
        let (proof, claims) = prove(&p, &s, &x, &y, v, &reads, &mut ch()).unwrap();
        let reject = |candidate: &Proof| {
            verify(&s, &x, &y, v, candidate, &mut ch())
                .and_then(|c| check_claims(&p, &reads, &c))
                .is_err()
        };
        for i in 0..3 {
            let mut bad = proof.clone();
            bad.matrix.terminal[i] += F128::ONE;
            assert!(reject(&bad));
        }
        for axis in 0..2 {
            for i in 0..7 {
                let mut bad = proof.clone();
                if axis == 0 {
                    bad.row.evaluations[i] += F128::ONE;
                } else {
                    bad.col.evaluations[i] += F128::ONE;
                }
                assert!(reject(&bad));
            }
        }
        let mut bad = proof.clone();
        bad.matrix.rounds.pop();
        assert!(reject(&bad));
        let mut bad = proof.clone();
        bad.row.product.trees[0].layers.pop();
        assert!(reject(&bad));
        let mut changed = p.clone();
        changed.row[0] ^= 1;
        assert!(check_claims(&changed, &reads, &claims).is_err());
        let mut changed = p.clone();
        changed.col[0] ^= 1;
        assert!(check_claims(&changed, &reads, &claims).is_err());
        let mut changed = p.clone();
        changed.value[s.nonzeros] = 1;
        assert!(check_claims(&changed, &reads, &claims).is_err());
        let mut changed = reads.clone();
        changed.read_row[0] += F128::new(0x7123, 0x999);
        assert!(check_claims(&p, &changed, &claims).is_err());
        // Recompute the matrix claim so only the lookup can detect the forged gather.
        let forged_value = value(&p, &changed);
        assert!(prove(&p, &s, &x, &y, forged_value, &changed, &mut ch()).is_err());
        assert!(verify(&s, &x, &y, v + F128::ONE, &proof, &mut ch()).is_err());
        let mut changed_s = s.clone();
        changed_s.digest[0] ^= 1;
        assert!(verify(&changed_s, &x, &y, v, &proof, &mut ch()).is_err());
        let mut changed_s = s.clone();
        changed_s.entry_log = MAX_LOG + 1;
        assert!(verify(&changed_s, &x, &y, v, &proof, &mut ch()).is_err());
    }

    #[test]
    fn sparse_lookup_timestamp_increment_is_integer_not_field_xor() {
        let matrix = SparseBinaryMatrix::new(1, 4, vec![vec![0, 1, 2]]);
        let p = Prepared::new(&matrix).unwrap();
        assert_eq!(p.row_read_time, [0, 1, 2, 3]);
        assert_eq!(p.row_write_time, [1, 2, 3, 4]);
        assert_ne!(
            raw(p.row_read_time[1]) + F128::ONE,
            raw(p.row_write_time[1])
        );
        assert_eq!(p.row_final_time, [4]);
        assert_eq!(p.value, [1, 1, 1, 0]);
        assert!(Prepared::new(&SparseBinaryMatrix::new(2, 2, vec![vec![2], vec![]])).is_err());
        assert!(
            Prepared::new(&SparseBinaryMatrix::new(3, 2, vec![vec![], vec![], vec![]])).is_err()
        );
    }

    #[test]
    fn sparse_lookup_canonicalizes_binary_postings_before_padding_and_timestamps() {
        let postings = vec![
            vec![65, 1, 65, 2, 2, 1], // Everything cancels, across two bitset words.
            vec![127, 64, 127, 3, 3, 3, 64], // Only column 3 remains.
            vec![7, 1, 7, 1, 7, 0],   // Columns 0 and 7 remain, in canonical order.
            vec![66, 66],
        ];
        let matrix = SparseBinaryMatrix::new(4, 128, postings.clone());
        let mut reordered = postings;
        for row in &mut reordered {
            row.reverse();
        }
        let reordered = SparseBinaryMatrix::new(4, 128, reordered);
        let p = Prepared::new(&matrix).unwrap();
        let same = Prepared::new(&reordered).unwrap();
        assert_eq!(p.nonzeros, 3);
        assert_eq!(p.entry_log, 2);
        assert_eq!(p.row, [1, 2, 2, 0]);
        assert_eq!(p.col, [3, 0, 7, 0]);
        assert_eq!(p.value, [1, 1, 1, 0]);
        for source in OracleId::STATIC {
            assert_eq!(p.static_column(source), same.static_column(source));
        }
        let empty = Prepared::new(&SparseBinaryMatrix::new(
            2,
            2,
            vec![vec![0, 0, 1, 1], vec![1, 1]],
        ))
        .unwrap();
        assert_eq!(empty.nonzeros, 0);
        assert_eq!(empty.value, [0]);
        assert_eq!(empty.row_final_time, [1, 0]);

        // Independent original-posting matrix evaluation, retaining every XOR
        // contribution, must agree with the canonical COO at several points.
        for seed in [0, 3, 29, 4091] {
            let x = query(p.row_log, seed);
            let y = query(p.col_log, seed + 101);
            let eq_x = eq_table(&x);
            let eq_y = eq_table(&y);
            let expected = matrix
                .rows
                .iter()
                .enumerate()
                .fold(F128::ZERO, |sum, (r, cols)| {
                    cols.iter().fold(sum, |sum, &c| sum + eq_x[r] * eq_y[c])
                });
            let reads = p.gather(&x, &y).unwrap();
            assert_eq!(value(&p, &reads), expected);
            let s = p.statement([11; 32]);
            let (proof, _) = prove(&p, &s, &x, &y, expected, &reads, &mut ch()).unwrap();
            let claims = verify(&s, &x, &y, expected, &proof, &mut ch()).unwrap();
            check_claims(&p, &reads, &claims).unwrap();
        }
    }
}
