//! 256 SHA compressions using the active R1CS sparse-lookup construction.
#![recursion_limit = "256"]
#![allow(dead_code)]
mod e2e_common;
#[path = "e2e_common/sparse_sha.rs"]
mod sparse_sha;
fn main() -> Result<(), Box<dyn std::error::Error>> {
    sparse_sha::main()
}
