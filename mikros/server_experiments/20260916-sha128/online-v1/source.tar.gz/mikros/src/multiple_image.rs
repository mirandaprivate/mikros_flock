//! Authenticate one virtual binary linear image through column projection.
//!
//! Implements `latex/6-together.tex`: fix the 128 column evaluations before
//! sampling a fresh coordinate projection, then run two ordinary IPs. The
//! verifier never receives or scans the sparse matrix. Its returned matrix
//! MLE MUST be authenticated by the caller's sparse/lookup proof against the
//! preprocessed circuit commitment. The witness MLE must reach the PCS too.
//! Bind both commitments and the enclosing statement before entering here.

use crate::{
    MatrixClaim,
    inner_product::{self, InnerProductProof, ProverScratch},
};
use flock_core::{
    pcs::{
        functional::row_weights,
        ring_switch::{build_fold_byte_table, fold_1b_rows_naive, linearized_coefficients},
    },
    r1cs::SparseBinaryMatrix,
};
use flock_field::{F128, F256Unreduced};
use flock_transcript::challenger::Challenger;
use rayon::prelude::*;
use serde::{Deserialize, Serialize};

const WIDTH: usize = 128;

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct PointClaim {
    /// Low-bit-first ordinary MLE point.
    pub point: Vec<F128>,
    pub value: F128,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct MatrixEvaluation {
    /// Both points are low-bit first: eq(row)^T S eq(column).
    pub row_point: Vec<F128>,
    pub column_point: Vec<F128>,
    pub value: F128,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Claims {
    pub witness: PointClaim,
    pub matrix: MatrixEvaluation,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct Proof {
    /// u = U^T beta. Each element exposes one column's 128 base coordinates.
    pub columns: Vec<F128>,
    pub ip1: InnerProductProof,
    pub ip2: InnerProductProof,
}

fn checked_shape(log_n: usize, source: &MatrixClaim) -> Result<usize, String> {
    if log_n >= usize::BITS as usize
        || source.row_factors.len() != log_n
        || source.column_weights.len() != WIDTH
    {
        return Err("multiple image query shape".into());
    }
    let n = 1usize << log_n;
    if n > isize::MAX as usize / size_of::<F128>() {
        return Err("multiple image dimension overflow".into());
    }
    Ok(n)
}

fn basis() -> Vec<F128> {
    (0..WIDTH)
        .map(|i| {
            if i < 64 {
                F128::new(1u64 << i, 0)
            } else {
                F128::new(0, 1u64 << (i - 64))
            }
        })
        .collect()
}

fn dot(a: &[F128], b: &[F128]) -> F128 {
    debug_assert_eq!(a.len(), b.len());
    a.par_chunks(4096)
        .zip(b.par_chunks(4096))
        .map(|(a, b)| {
            a.iter().zip(b).fold(F256Unreduced::ZERO, |sum, (&a, &b)| {
                sum ^ a.mul_unreduced(b)
            })
        })
        .reduce(|| F256Unreduced::ZERO, |a, b| a ^ b)
        .reduce()
}

fn bind<C: Challenger>(log_n: usize, source: &MatrixClaim, ch: &mut C) {
    ch.observe_label(b"mikros-multiple-image-column-projection-v1");
    ch.observe_bytes(&(log_n as u64).to_le_bytes());
    ch.observe_bytes(&(WIDTH as u64).to_le_bytes());
    ch.observe_f128_slice(&source.column_weights);
    for pair in &source.row_factors {
        ch.observe_f128_slice(pair);
    }
    ch.observe_f128(source.value);
}

fn column_message<C: Challenger>(columns: &[F128], ch: &mut C) -> Vec<F128> {
    ch.observe_label(b"mikros-multiple-image-columns-v1");
    ch.observe_f128_slice(columns);
    // No projection challenge is sampled before ALL column messages are fixed.
    ch.sample_f128_vec(WIDTH)
}

fn projected_claim(columns: &[F128], projection: &[F128]) -> F128 {
    // Input word j carries U_{i,j} in bit i. Folding with beta_j packs U's
    // rows, exactly U beta, rather than reusing the transposed column packing.
    let packed_rows = fold_1b_rows_naive(columns, &basis());
    dot(projection, &packed_rows)
}

fn project_coordinate(value: F128, tables: &[F128]) -> F128 {
    value
        .lo
        .to_le_bytes()
        .into_iter()
        .chain(value.hi.to_le_bytes())
        .enumerate()
        .fold(F128::ZERO, |sum, (i, byte)| {
            sum + tables[i * 256 + byte as usize]
        })
}

fn tensor_high(factors: &[[F128; 2]]) -> Vec<F128> {
    row_weights(&factors.iter().rev().copied().collect::<Vec<_>>())
}

fn eq_low(point: &[F128]) -> Vec<F128> {
    row_weights(
        &point
            .iter()
            .map(|&x| [F128::ONE + x, x])
            .collect::<Vec<_>>(),
    )
}

/// Evaluate eq(point)^T Xi projection without materializing Xi or a length-N
/// tensor. The coordinate map Phi(t)=sum_j projection_j bit_j(t) is F2-linear:
/// Phi(t)=sum_h coeff_h t^(2^h). Frobenius preserves products, so each term's
/// sum over Boolean indices factors into log(N) independent two-entry sums.
/// No normalizer is inverted, including [a,a], zero pairs and 0/1 points.
fn evaluate_public_query(source: &MatrixClaim, projection: &[F128], point: &[F128]) -> F128 {
    debug_assert_eq!(source.row_factors.len(), point.len());
    let coefficients = linearized_coefficients(&build_fold_byte_table(projection));
    let mut powers: Vec<_> = source.row_factors.iter().rev().copied().collect();
    let mut result = F128::ZERO;
    for coefficient in coefficients {
        let product = powers
            .iter()
            .zip(point)
            .fold(F128::ONE, |product, (pair, &x)| {
                product * ((F128::ONE + x) * pair[0] + x * pair[1])
            });
        result += coefficient * product;
        for pair in &mut powers {
            pair[0] = pair[0].square();
            pair[1] = pair[1].square();
        }
    }
    result
}

fn sparse_apply(matrix: &SparseBinaryMatrix, values: &[F128]) -> Vec<F128> {
    matrix
        .rows
        .par_iter()
        .map(|columns| {
            columns
                .iter()
                .fold(F128::ZERO, |sum, &column| sum + values[column])
        })
        .collect()
}

fn sparse_transpose_apply(matrix: &SparseBinaryMatrix, values: &[F128]) -> Vec<F128> {
    let mut result = vec![F128::ZERO; matrix.num_cols];
    for (columns, &value) in matrix.rows.iter().zip(values) {
        for &column in columns {
            result[column] += value;
        }
    }
    result
}

fn native_ip<C: Challenger>(
    a: Vec<F128>,
    b: Vec<F128>,
    ch: &mut C,
) -> (InnerProductProof, Vec<F128>) {
    let mut scratch = ProverScratch::default();
    scratch.a = a;
    scratch.b = b;
    let (proof, mut high_point) = inner_product::prove_native(&mut scratch, None, ch);
    high_point.reverse();
    (proof, high_point)
}

fn claims(proof: &Proof, y: Vec<F128>, x: Vec<F128>) -> Claims {
    Claims {
        witness: PointClaim {
            point: y.clone(),
            value: proof.ip1.final_a,
        },
        matrix: MatrixEvaluation {
            row_point: x,
            column_point: y,
            value: proof.ip2.final_a,
        },
    }
}

pub fn prove<C: Challenger>(
    matrix: &SparseBinaryMatrix,
    witness: &[F128],
    image: &[F128],
    source: &MatrixClaim,
    ch: &mut C,
) -> Result<(Proof, Claims), String> {
    let log_n = source.row_factors.len();
    let n = checked_shape(log_n, source)?;
    if witness.len() != n
        || image.len() != n
        || matrix.num_rows != n
        || matrix.num_cols != n
        || matrix.rows.len() != n
        || matrix.rows.iter().flatten().any(|&column| column >= n)
    {
        return Err("multiple image sparse matrix/input shape".into());
    }
    bind(log_n, source, ch);
    let xi = tensor_high(&source.row_factors);
    let columns = fold_1b_rows_naive(image, &xi);
    if dot(&columns, &source.column_weights) != source.value {
        return Err("multiple image column scalar check".into());
    }
    let projection = column_message(&columns, ch);
    let scalar = projected_claim(&columns, &projection);
    let table = build_fold_byte_table(&projection);
    let xi_projection: Vec<_> = xi
        .par_iter()
        .map(|&x| project_coordinate(x, &table))
        .collect();
    let rhs = sparse_transpose_apply(matrix, &xi_projection);
    if dot(witness, &rhs) != scalar {
        return Err("multiple image projected identity".into());
    }
    ch.observe_label(b"mikros-multiple-image-first-ip-v1");
    let (ip1, y) = native_ip(witness.to_vec(), rhs, ch);
    let image_eq_y = sparse_apply(matrix, &eq_low(&y));
    if dot(&image_eq_y, &xi_projection) != ip1.final_b {
        return Err("multiple image second IP identity".into());
    }
    ch.observe_label(b"mikros-multiple-image-second-ip-v1");
    let (ip2, x) = native_ip(image_eq_y, xi_projection, ch);
    let proof = Proof { columns, ip1, ip2 };
    debug_assert_eq!(proof.ip1.rounds.len(), log_n);
    debug_assert_eq!(proof.ip2.rounds.len(), log_n);
    let claims = claims(&proof, y, x);
    Ok((proof, claims))
}

pub fn verify<C: Challenger>(
    log_n: usize,
    source: &MatrixClaim,
    proof: &Proof,
    ch: &mut C,
) -> Result<Claims, String> {
    checked_shape(log_n, source)?;
    if proof.columns.len() != WIDTH
        || proof.ip1.rounds.len() != log_n
        || proof.ip2.rounds.len() != log_n
    {
        return Err("multiple image proof shape".into());
    }
    bind(log_n, source, ch);
    if dot(&proof.columns, &source.column_weights) != source.value {
        return Err("multiple image column scalar check".into());
    }
    let projection = column_message(&proof.columns, ch);
    let scalar = projected_claim(&proof.columns, &projection);
    ch.observe_label(b"mikros-multiple-image-first-ip-v1");
    let mut y = inner_product::verify(&proof.ip1, scalar, ch)
        .map_err(|e| format!("multiple image first IP: {e:?}"))?;
    y.reverse();
    ch.observe_label(b"mikros-multiple-image-second-ip-v1");
    let mut x = inner_product::verify(&proof.ip2, proof.ip1.final_b, ch)
        .map_err(|e| format!("multiple image second IP: {e:?}"))?;
    x.reverse();
    if evaluate_public_query(source, &projection, &x) != proof.ip2.final_b {
        return Err("multiple image public tensor recursion".into());
    }
    Ok(claims(proof, y, x))
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct BatchProof {
    /// One original binary coordinate matrix per block; never combine these
    /// packed columns by F128 multiplication before coordinate extraction.
    pub columns: Vec<Vec<F128>>,
    pub ip1: InnerProductProof,
    pub ip2: InnerProductProof,
}

#[derive(Clone, Debug, PartialEq, Eq, Serialize, Deserialize)]
pub struct BatchClaims {
    /// Opening of sum_j weights[j] * witness[j], at a LOW FIRST point.
    pub witness: PointClaim,
    pub matrix: MatrixEvaluation,
    pub weights: Vec<F128>,
}

fn batch_shape(log_n: usize, sources: &[MatrixClaim]) -> Result<usize, String> {
    let first = sources.first().ok_or("empty image batch")?;
    let n = checked_shape(log_n, first)?;
    for source in sources {
        checked_shape(log_n, source)?;
        if source.row_factors != first.row_factors {
            return Err("image batch requires identical row factors".into());
        }
    }
    Ok(n)
}

fn batch_transcript<C: Challenger>(
    log_n: usize,
    sources: &[MatrixClaim],
    columns: &[Vec<F128>],
    ch: &mut C,
) -> Result<(Vec<F128>, Vec<F128>, F128), String> {
    if columns.len() != sources.len() || columns.iter().any(|u| u.len() != WIDTH) {
        return Err("image batch column shape".into());
    }
    ch.observe_label(b"mikros-multiple-image-shared-query-batch-v1");
    ch.observe_bytes(&(sources.len() as u64).to_le_bytes());
    for (source, u) in sources.iter().zip(columns) {
        bind(log_n, source, ch);
        if dot(u, &source.column_weights) != source.value {
            return Err("image batch column scalar check".into());
        }
        ch.observe_label(b"mikros-image-batch-fixed-columns-v1");
        ch.observe_f128_slice(u);
    }
    // All U_j are fixed before both independent random reductions.
    ch.observe_label(b"mikros-image-batch-weights-v1");
    let weights = ch.sample_f128_vec(sources.len());
    ch.observe_label(b"mikros-image-batch-coordinate-projection-v1");
    let projection = ch.sample_f128_vec(WIDTH);
    let scalar = columns
        .iter()
        .zip(&weights)
        .fold(F128::ZERO, |sum, (u, &z)| {
            // Coordinate extraction is only F2-linear. Apply it to each U_j first.
            sum + z * projected_claim(u, &projection)
        });
    Ok((weights, projection, scalar))
}

fn batch_claims(proof: &BatchProof, y: Vec<F128>, x: Vec<F128>, weights: Vec<F128>) -> BatchClaims {
    BatchClaims {
        witness: PointClaim {
            point: y.clone(),
            value: proof.ip1.final_a,
        },
        matrix: MatrixEvaluation {
            row_point: x,
            column_point: y,
            value: proof.ip2.final_a,
        },
        weights,
    }
}

/// Authenticate several independent image claims sharing one row tensor and
/// one binary matrix. Bind every witness/circuit commitment before entry.
/// Caller authenticates the returned matrix claim and weighted witness claim.
pub fn prove_batch<C: Challenger>(
    matrix: &SparseBinaryMatrix,
    witnesses: &[&[F128]],
    images: &[&[F128]],
    sources: &[MatrixClaim],
    ch: &mut C,
) -> Result<(BatchProof, BatchClaims), String> {
    let log_n = sources
        .first()
        .ok_or("empty image batch")?
        .row_factors
        .len();
    let n = batch_shape(log_n, sources)?;
    if witnesses.len() != sources.len()
        || images.len() != sources.len()
        || witnesses.iter().chain(images).any(|w| w.len() != n)
        || matrix.num_rows != n
        || matrix.num_cols != n
        || matrix.rows.len() != n
        || matrix.rows.iter().flatten().any(|&column| column >= n)
    {
        return Err("image batch input shape".into());
    }
    let xi = tensor_high(&sources[0].row_factors);
    let columns: Vec<_> = images
        .iter()
        .map(|image| fold_1b_rows_naive(image, &xi))
        .collect();
    let (weights, projection, scalar) = batch_transcript(log_n, sources, &columns, ch)?;
    let table = build_fold_byte_table(&projection);
    let xi_projection: Vec<_> = xi
        .par_iter()
        .map(|&x| project_coordinate(x, &table))
        .collect();
    let combined: Vec<_> = (0..n)
        .into_par_iter()
        .map(|i| {
            witnesses
                .iter()
                .zip(&weights)
                .fold(F128::ZERO, |sum, (w, &z)| sum + z * w[i])
        })
        .collect();
    let rhs = sparse_transpose_apply(matrix, &xi_projection);
    if dot(&combined, &rhs) != scalar {
        return Err("image batch projected identity".into());
    }
    ch.observe_label(b"mikros-multiple-image-first-ip-v1");
    let (ip1, y) = native_ip(combined, rhs, ch);
    let image_eq_y = sparse_apply(matrix, &eq_low(&y));
    if dot(&image_eq_y, &xi_projection) != ip1.final_b {
        return Err("image batch second IP identity".into());
    }
    ch.observe_label(b"mikros-multiple-image-second-ip-v1");
    let (ip2, x) = native_ip(image_eq_y, xi_projection, ch);
    let proof = BatchProof { columns, ip1, ip2 };
    let claims = batch_claims(&proof, y, x, weights);
    Ok((proof, claims))
}

pub fn verify_batch<C: Challenger>(
    log_n: usize,
    sources: &[MatrixClaim],
    proof: &BatchProof,
    ch: &mut C,
) -> Result<BatchClaims, String> {
    batch_shape(log_n, sources)?;
    if proof.ip1.rounds.len() != log_n || proof.ip2.rounds.len() != log_n {
        return Err("image batch IP shape".into());
    }
    let (weights, projection, scalar) = batch_transcript(log_n, sources, &proof.columns, ch)?;
    ch.observe_label(b"mikros-multiple-image-first-ip-v1");
    let mut y = inner_product::verify(&proof.ip1, scalar, ch)
        .map_err(|e| format!("image batch first IP: {e:?}"))?;
    y.reverse();
    ch.observe_label(b"mikros-multiple-image-second-ip-v1");
    let mut x = inner_product::verify(&proof.ip2, proof.ip1.final_b, ch)
        .map_err(|e| format!("image batch second IP: {e:?}"))?;
    x.reverse();
    if evaluate_public_query(&sources[0], &projection, &x) != proof.ip2.final_b {
        return Err("image batch public tensor recursion".into());
    }
    Ok(batch_claims(proof, y, x, weights))
}

#[cfg(test)]
mod tests {
    use super::*;
    use flock_field::test_rng::Rng;
    use flock_transcript::challenger::FsChallenger;

    fn fixture(log_n: usize, seed: u64) -> (SparseBinaryMatrix, Vec<F128>, Vec<F128>, MatrixClaim) {
        let n = 1 << log_n;
        let matrix = SparseBinaryMatrix::new(
            n,
            n,
            (0..n)
                .map(|i| {
                    if n == 1 {
                        vec![0]
                    } else if i % 3 == 0 {
                        vec![]
                    } else {
                        vec![(i + 1) % n, (i * 3 + 2) % n]
                    }
                })
                .collect(),
        );
        let mut rng = Rng::new(seed);
        let witness = rng.f128_vec(n);
        let image = sparse_apply(&matrix, &witness);
        let mut row_factors: Vec<_> = (0..log_n).map(|_| [rng.f128(), rng.f128()]).collect();
        if log_n > 1 {
            row_factors[0] = [rng.f128(); 2];
        }
        let column_weights = rng.f128_vec(WIDTH);
        let columns = fold_1b_rows_naive(&image, &tensor_high(&row_factors));
        let value = dot(&columns, &column_weights);
        (
            matrix,
            witness,
            image,
            MatrixClaim {
                row_factors,
                column_weights,
                value,
            },
        )
    }

    fn check_sources(matrix: &SparseBinaryMatrix, witness: &[F128], c: &Claims) {
        assert_eq!(dot(witness, &eq_low(&c.witness.point)), c.witness.value);
        assert_eq!(
            dot(
                &eq_low(&c.matrix.row_point),
                &sparse_apply(matrix, &eq_low(&c.matrix.column_point))
            ),
            c.matrix.value
        );
        assert_eq!(c.witness.point, c.matrix.column_point);
    }

    #[test]
    fn nonidentity_roundtrip_all_endpoints_and_low_first_points() {
        for log_n in [0, 1, 3, 7, 9] {
            let (matrix, witness, image, source) = fixture(log_n, 0xA900 + log_n as u64);
            let mut pc = FsChallenger::new(b"multiple-image-roundtrip");
            let (proof, c) = prove(&matrix, &witness, &image, &source, &mut pc).unwrap();
            check_sources(&matrix, &witness, &c);
            let mut vc = FsChallenger::new(b"multiple-image-roundtrip");
            assert_eq!(verify(log_n, &source, &proof, &mut vc).unwrap(), c);
            assert_eq!(pc.sample_f128(), vc.sample_f128());
        }
    }

    #[test]
    fn public_frobenius_recursion_matches_direct_coordinate_projection() {
        let mut rng = Rng::new(0xA901);
        for log_n in [0, 1, 4, 9] {
            let projection = rng.f128_vec(WIDTH);
            let mut source = MatrixClaim {
                row_factors: (0..log_n).map(|_| [rng.f128(), rng.f128()]).collect(),
                column_weights: vec![F128::ZERO; WIDTH],
                value: F128::ZERO,
            };
            if log_n > 1 {
                source.row_factors[0] = [F128::ONE; 2];
                source.row_factors[1] = [F128::ZERO, F128::ONE];
            }
            for mode in 0..3 {
                let point = if mode == 0 {
                    vec![F128::ZERO; log_n]
                } else if mode == 1 {
                    vec![F128::ONE; log_n]
                } else {
                    rng.f128_vec(log_n)
                };
                let table = build_fold_byte_table(&projection);
                let direct: Vec<_> = tensor_high(&source.row_factors)
                    .into_iter()
                    .map(|v| project_coordinate(v, &table))
                    .collect();
                assert_eq!(
                    evaluate_public_query(&source, &projection, &point),
                    dot(&eq_low(&point), &direct)
                );
            }
            if log_n > 0 {
                source.row_factors[log_n - 1] = [F128::ZERO; 2];
                assert_eq!(
                    evaluate_public_query(&source, &projection, &rng.f128_vec(log_n)),
                    F128::ZERO
                );
            }
        }
    }

    #[test]
    fn columns_rounds_endpoints_and_source_tampering_rejected() {
        let log_n = 4;
        let (matrix, witness, image, source) = fixture(log_n, 0xA902);
        let (proof, _) = prove(
            &matrix,
            &witness,
            &image,
            &source,
            &mut FsChallenger::new(b"multiple-image-tamper"),
        )
        .unwrap();
        for kind in 0..9 {
            let mut p = proof.clone();
            match kind {
                0 => p.columns[17] += F128::ONE,
                1 => p.ip1.rounds[1][0] += F128::ONE,
                2 => p.ip2.rounds[2][1] += F128::ONE,
                3 => p.ip1.final_a += F128::ONE,
                4 => p.ip1.final_b += F128::ONE,
                5 => p.ip2.final_a += F128::ONE,
                6 => p.ip2.final_b += F128::ONE,
                7 => {
                    p.ip1.rounds.pop();
                }
                _ => {
                    p.columns.pop();
                }
            }
            assert!(
                verify(
                    log_n,
                    &source,
                    &p,
                    &mut FsChallenger::new(b"multiple-image-tamper")
                )
                .is_err(),
                "kind={kind}"
            );
        }
        let mut wrong = source.clone();
        wrong.row_factors.reverse();
        assert!(
            verify(
                log_n,
                &wrong,
                &proof,
                &mut FsChallenger::new(b"multiple-image-tamper")
            )
            .is_err()
        );
        let mut wrong = source.clone();
        wrong.value += F128::ONE;
        assert!(
            prove(
                &matrix,
                &witness,
                &image,
                &wrong,
                &mut FsChallenger::new(b"multiple-image-tamper")
            )
            .is_err()
        );
        let mut wrong = image;
        wrong[0] += F128::ONE;
        assert!(
            prove(
                &matrix,
                &witness,
                &wrong,
                &source,
                &mut FsChallenger::new(b"multiple-image-tamper")
            )
            .is_err()
        );
    }

    fn batch_fixture(
        log_n: usize,
        count: usize,
    ) -> (
        SparseBinaryMatrix,
        Vec<Vec<F128>>,
        Vec<Vec<F128>>,
        Vec<MatrixClaim>,
    ) {
        let (matrix, _, _, first) = fixture(log_n, 0xBABA_0100);
        let mut witnesses = Vec::new();
        let mut images = Vec::new();
        let mut sources = Vec::new();
        for i in 0..count {
            let (_, witness, image, mut source) = fixture(log_n, 0xBABA_0200 + i as u64);
            source.row_factors = first.row_factors.clone();
            source.value = dot(
                &fold_1b_rows_naive(&image, &tensor_high(&source.row_factors)),
                &source.column_weights,
            );
            witnesses.push(witness);
            images.push(image);
            sources.push(source);
        }
        (matrix, witnesses, images, sources)
    }

    #[test]
    fn batch_projection_and_terminals_match_independent_sources() {
        for (log_n, count) in [(0, 2), (4, 1), (4, 2), (5, 3)] {
            let (matrix, witnesses, images, sources) = batch_fixture(log_n, count);
            let ws: Vec<_> = witnesses.iter().map(Vec::as_slice).collect();
            let ims: Vec<_> = images.iter().map(Vec::as_slice).collect();
            let mut pc = FsChallenger::new(b"batch-image-test");
            let (proof, c) = prove_batch(&matrix, &ws, &ims, &sources, &mut pc).unwrap();
            let mut vc = FsChallenger::new(b"batch-image-test");
            assert_eq!(verify_batch(log_n, &sources, &proof, &mut vc).unwrap(), c);
            assert_eq!(pc.sample_f128(), vc.sample_f128());
            let combined: Vec<_> = (0..1 << log_n)
                .map(|i| {
                    witnesses
                        .iter()
                        .zip(&c.weights)
                        .fold(F128::ZERO, |s, (w, &z)| s + w[i] * z)
                })
                .collect();
            check_sources(
                &matrix,
                &combined,
                &Claims {
                    witness: c.witness,
                    matrix: c.matrix,
                },
            );
        }
        // Demonstrate why F128-weighted packed columns cannot be transposed
        // after combination: the coordinate transpose is only F2-linear.
        let mut rng = Rng::new(0xBA7C_00F2);
        let left = rng.f128_vec(WIDTH);
        let right = rng.f128_vec(WIDTH);
        let r = rng.f128_vec(WIDTH);
        let z = [rng.f128(), rng.f128()];
        let wrong: Vec<_> = left
            .iter()
            .zip(&right)
            .map(|(&a, &b)| z[0] * a + z[1] * b)
            .collect();
        assert_ne!(
            projected_claim(&wrong, &r),
            z[0] * projected_claim(&left, &r) + z[1] * projected_claim(&right, &r)
        );
    }

    #[test]
    fn batch_columns_endpoints_swaps_and_different_queries_rejected() {
        let log_n = 4;
        let (matrix, witnesses, images, sources) = batch_fixture(log_n, 2);
        let ws: Vec<_> = witnesses.iter().map(Vec::as_slice).collect();
        let ims: Vec<_> = images.iter().map(Vec::as_slice).collect();
        let (proof, _) = prove_batch(
            &matrix,
            &ws,
            &ims,
            &sources,
            &mut FsChallenger::new(b"batch-image-tamper"),
        )
        .unwrap();
        for kind in 0..8 {
            let mut bad = proof.clone();
            match kind {
                0 => bad.columns.swap(0, 1),
                1 => bad.columns[1][0] += F128::ONE,
                2 => bad.ip1.final_a += F128::ONE,
                3 => bad.ip1.final_b += F128::ONE,
                4 => bad.ip2.final_a += F128::ONE,
                5 => bad.ip2.final_b += F128::ONE,
                6 => {
                    bad.ip2.rounds.pop();
                }
                _ => {
                    bad.columns.pop();
                }
            }
            assert!(
                verify_batch(
                    log_n,
                    &sources,
                    &bad,
                    &mut FsChallenger::new(b"batch-image-tamper")
                )
                .is_err(),
                "kind={kind}"
            );
        }
        let mut wrong = sources.clone();
        wrong[1].row_factors[0][0] += F128::ONE;
        assert!(
            verify_batch(
                log_n,
                &wrong,
                &proof,
                &mut FsChallenger::new(b"batch-image-tamper")
            )
            .is_err()
        );
        assert!(
            prove_batch(
                &matrix,
                &ws,
                &ims,
                &wrong,
                &mut FsChallenger::new(b"batch-image-tamper")
            )
            .is_err()
        );
        let swapped = [sources[1].clone(), sources[0].clone()];
        assert!(
            verify_batch(
                log_n,
                &swapped,
                &proof,
                &mut FsChallenger::new(b"batch-image-tamper")
            )
            .is_err()
        );
    }
}
