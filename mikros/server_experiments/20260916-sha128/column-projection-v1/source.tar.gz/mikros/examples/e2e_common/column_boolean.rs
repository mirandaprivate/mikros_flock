//! Packed R1CS: independent Hadamards, shared row queries, column projection.
//! Public CSC checks the matrix endpoints directly. All witness endpoints,
//! including C=I, are authenticated by the original native PCS commitment.
use super::{TreeFixture, TreeVerifier, batched_boolean::TransposedWitness};
use flock_core::{challenger::Challenger, lincheck::LincheckCircuit, pcs::functional::TensorClaim};
use flock_field::F128;
use mikros::{MatrixClaim, hadamard, multiple_image};
use rayon::prelude::*;
use serde::{Deserialize, Serialize};

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Proof {
    pub hadamards: Vec<hadamard::Proof>,
    pub linchecks: Vec<multiple_image::PublicBatchProof>,
}
pub struct Claims {
    pub other: Vec<TensorClaim>,
}
fn shape(view: &TreeVerifier<'_>) -> Result<usize, String> {
    if view.nu != 8 || view.live_rows != 256 || !(7..=24).contains(&view.r1cs.k_log) {
        return Err("column R1CS requires 256 live executions".into());
    }
    let n = 1 << view.r1cs.k_log;
    if !view.r1cs.c0_is_identity() || view.r1cs.csc_lincheck_circuit().n_cols() != n {
        return Err("column R1CS requires native public CSC and C=I".into());
    }
    Ok(n)
}
fn basis() -> Vec<F128> {
    (0..128)
        .map(|j| {
            if j < 64 {
                F128::new(1u64 << j, 0)
            } else {
                F128::new(0, 1u64 << (j - 64))
            }
        })
        .collect()
}
fn start<C: Challenger>(log_n: usize, ch: &mut C) {
    ch.observe_label(b"mikros-sha256-packed-r1cs-column-projection-v1");
    ch.observe_bytes(&(log_n as u64).to_le_bytes());
    ch.observe_bytes(&256u64.to_le_bytes());
}
fn witness_claim(claim: multiple_image::PublicBatchClaims) -> Result<TensorClaim, String> {
    // The group factors may sum to zero; no normalization is allowed.
    let weights: [F128; 2] = claim
        .weights
        .try_into()
        .map_err(|_| "column R1CS block weights")?;
    let mut rows = vec![weights];
    rows.extend(claim.witness.point.iter().map(|&r| [F128::ONE + r, r]));
    Ok(TensorClaim {
        columns: basis(),
        rows,
        value: claim.witness.value,
    })
}
fn identity_claim(group: usize, query: &MatrixClaim) -> TensorClaim {
    let mut rows = vec![if group == 0 {
        [F128::ONE, F128::ZERO]
    } else {
        [F128::ZERO, F128::ONE]
    }];
    rows.extend(query.row_factors.iter().rev().copied());
    TensorClaim {
        columns: query.column_weights.clone(),
        rows,
        value: query.value,
    }
}
fn bytes(words: &[F128]) -> &[u8] {
    assert!(cfg!(target_endian = "little"));
    // F128 is repr(C), lo then hi, representing binary instance coordinates.
    unsafe { std::slice::from_raw_parts(words.as_ptr().cast(), std::mem::size_of_val(words)) }
}
pub fn prove<C: Challenger>(
    fixture: &TreeFixture,
    witness: &TransposedWitness,
    ch: &mut C,
) -> Result<(Proof, Claims), String> {
    let view = fixture.verifier();
    let n = shape(&view)?;
    if [&witness.z, &witness.a, &witness.b]
        .iter()
        .any(|v| v.len() != 2 * n)
    {
        return Err("column R1CS transposed witness shape".into());
    }
    start(view.r1cs.k_log, ch);
    // Temporary deinterleaving is included in online time, unlike the initial
    // challenge-independent conversion common to the compared modes.
    let packed: [Vec<F128>; 2] =
        std::array::from_fn(|group| witness.z.par_chunks_exact(2).map(|w| w[group]).collect());
    let a = [bytes(&witness.a[..n]), bytes(&witness.a[n..])];
    let b = [bytes(&witness.b[..n]), bytes(&witness.b[n..])];
    let c = [bytes(&packed[0]), bytes(&packed[1])];
    let (hadamards, sources) = hadamard::prove_batch_shared_rows(
        &a,
        &b,
        &c,
        view.r1cs.k_log + 7,
        mikros::Kernel::PairAggregate,
        ch,
    )
    .map_err(|e| format!("column R1CS Hadamard: {e:?}"))?;
    let mut linchecks = Vec::with_capacity(2);
    let mut other = Vec::with_capacity(4);
    let witnesses = [packed[0].as_slice(), packed[1].as_slice()];
    for side in 0..2 {
        ch.observe_label(b"mikros-column-r1cs-linear-image-batch-v1");
        ch.observe_bytes(&(side as u64).to_le_bytes());
        let image = if side == 0 { &witness.a } else { &witness.b };
        let queries: Vec<_> = sources
            .iter()
            .map(|q| if side == 0 { q.a.clone() } else { q.b.clone() })
            .collect();
        let (proof, claim) = multiple_image::prove_public_batch(
            view.r1cs.csc_lincheck_circuit(),
            side == 0,
            &witnesses,
            &[&image[..n], &image[n..]],
            &queries,
            ch,
        )?;
        linchecks.push(proof);
        other.push(witness_claim(claim)?);
    }
    other.extend(
        sources
            .iter()
            .enumerate()
            .map(|(group, q)| identity_claim(group, &q.c)),
    );
    Ok((
        Proof {
            hadamards,
            linchecks,
        },
        Claims { other },
    ))
}
pub fn verify<C: Challenger>(
    view: &TreeVerifier<'_>,
    proof: &Proof,
    ch: &mut C,
) -> Result<Claims, String> {
    shape(view)?;
    if proof.hadamards.len() != 2 || proof.linchecks.len() != 2 {
        return Err("column R1CS proof block count".into());
    }
    start(view.r1cs.k_log, ch);
    let sources = hadamard::verify_batch_shared_rows(&proof.hadamards, view.r1cs.k_log + 7, ch)
        .map_err(|e| format!("column R1CS Hadamard verify: {e:?}"))?;
    let mut other = Vec::with_capacity(4);
    for side in 0..2 {
        ch.observe_label(b"mikros-column-r1cs-linear-image-batch-v1");
        ch.observe_bytes(&(side as u64).to_le_bytes());
        let queries: Vec<_> = sources
            .iter()
            .map(|q| if side == 0 { q.a.clone() } else { q.b.clone() })
            .collect();
        let claim = multiple_image::verify_public_batch(
            view.r1cs.csc_lincheck_circuit(),
            side == 0,
            &queries,
            &proof.linchecks[side],
            ch,
        )?;
        other.push(witness_claim(claim)?);
    }
    other.extend(
        sources
            .iter()
            .enumerate()
            .map(|(group, q)| identity_claim(group, &q.c)),
    );
    Ok(Claims { other })
}
