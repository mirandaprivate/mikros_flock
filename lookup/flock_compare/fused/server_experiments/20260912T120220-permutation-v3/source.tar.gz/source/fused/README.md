# Fused first product layer for Mikros permutation

Independent v3 candidate; `previous` compiles the unchanged streaming v2 crate.
For K64 inputs and a coefficient capacity of 128 bits, fuse bit decoding,
compact leaf storage, leaf evaluation and first-layer pair multiplication.
This keeps the same source oracles, cubic proof bytes, transcript and verifier.
Other widths, capacities and the full-extension strategy retain the v2 path.

Benchmarks include native input conversion and synchronous cleanup. Source
authentication is separately measured. This is a permutation PIOP, without PCS,
commitments, openings or grinding. See THEORY.md for protocol comparison.
