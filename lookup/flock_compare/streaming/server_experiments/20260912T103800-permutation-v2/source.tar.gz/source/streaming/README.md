# Streaming Mikros permutation candidate

Independent successor to ../optimized. It preserves the original cubic proof,
claims, and transcript. The previous candidate is compiled separately as the
`previous` dependency and compared on identical paired input.

Changes under measurement:
- Compact layers are evaluated in at most 16 KiB blocks inside the first GKR
  message/fold scans, without a full expanded temporary array.
- Used tree layers are released synchronously and their release time is counted.
- `release` isolates early release with the old full materialization; `optimized`
  adds streaming, and `full` applies early release to full-extension trees.
- `previous` and `previous_full` run the unmodified earlier candidate.

All modes replay the verifier and authenticate every original source claim.
This remains a permutation PIOP comparison without PCS or grinding.

```sh
cargo +nightly-2026-03-21 test --release --locked -- --test-threads=1
cargo +nightly-2026-03-21 build --release --locked --bin compare
target/release/compare --log-n 20 --threads 6 --runs 6 --out results/NEW.json
```
